# This is really just an example!
# Place other .rb files in this directory and they will be detected
# on script startup and added to the snippets menu.