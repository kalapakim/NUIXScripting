# Menu Title: Custom Metadata from CSV 2
# Needs Case: true
# Needs Selected Items: false

require_relative "Nx.jar"
java_import "com.nuix.nx.NuixConnection"
java_import "com.nuix.nx.LookAndFeelHelper"
java_import "com.nuix.nx.dialogs.ChoiceDialog"
java_import "com.nuix.nx.dialogs.CustomDialog"
java_import "com.nuix.nx.dialogs.TabbedCustomDialog"
java_import "com.nuix.nx.dialogs.CommonDialogs"
java_import "com.nuix.nx.dialogs.ProgressDialog"

LookAndFeelHelper.setWindowsIfMetal
NuixConnection.setUtilities($utilities)
NuixConnection.setCurrentNuixVersion(NUIX_VERSION)

dialog = TabbedCustomDialog.new("Custom Metadata from CSV 2")
dialog.enableStickySettings(File.join(File.dirname(__FILE__),"RecentSettings.json"))
dialog.setHelpFile(File.join(File.dirname(__FILE__),"Readme.html"))

main_tab = dialog.addTab("main_tab","Main")
main_tab.appendOpenFileChooser("input_csv","Input CSV","Comma Separated Values","csv")
main_tab.appendCheckBox("apply_empty_values","Apply Empty Values",false)
main_tab.appendCheckBox("include_families","Include Families",false)
main_tab.appendCheckBox("tag_items","Tag Affected Items",false)
main_tab.appendTextField("tag_name","Tag Name","BulkCustomMetadataApplied")
main_tab.enabledOnlyWhenChecked("tag_name","tag_items")

reserved_column_names = {
	"QUERY" => true,
	"MD5" => true,
	"DOCUMENT_ID" => true,
	"GUID" => true,
}

dialog.display
if dialog.getDialogResult == true
	if CommonDialogs.getConfirmation("To prevent potential errors applying custom metadata, all tabs will now be closed, proceed?")
		$window.closeAllTabs
	else
		exit 1
	end

	values = dialog.toMap
	apply_empty_values = values["apply_empty_values"]
	include_families = values["include_families"]
	tag_name = values["tag_name"]
	
	require 'csv'
	current_row_number = 0
	annotater = $utilities.getBulkAnnotater
	iutil = $utilities.getItemUtility

	ProgressDialog.forBlock do |pd|
		pd.setTitle("Custom Metadata from CSV 2")
		pd.setAbortButtonVisible(false)

		CSV.foreach(values["input_csv"], headers: true) do |row|
			current_row_number += 1
			pd.setMainStatus("Processing CSV Row #{current_row_number}")
			resolution_method = nil
			# Resolve relevant items
			relevant_items = nil
			if !row["QUERY"].nil? && !row["QUERY"].strip.empty?
				relevant_items = $current_case.searchUnsorted(row["QUERY"])
				resolution_method = :query
			elsif !row["MD5"].nil? && !row["MD5"].strip.empty?
				relevant_items = $current_case.searchUnsorted("md5:\"#{row["MD5"]}\"")
				resolution_method = :md5
			elsif !row["DOCUMENT_ID"].nil? && !row["DOCUMENT_ID"].strip.empty?
				relevant_items = $current_case.searchUnsorted("document-id:\"#{row["DOCUMENT_ID"]}\"")
				resolution_method = :docid
			elsif !row["GUID"].nil? && !row["GUID"].strip.empty?
				relevant_items = $current_case.searchUnsorted("guid:\"#{row["GUID"]}\"")
				resolution_method = :guid
			else
				# Report that we could not find a usable value to resolve items for this row
				pd.logMessage "Unable to determine an item resolution method from CSV row #{current_row_number}"
				next
			end

			# Report if no items where located using supplied resolution method
			if relevant_items.nil? || relevant_items.size < 1
				case resolution_method
				when :query
					pd.logMessage "Query on row #{current_row_number} yielded no hits: #{row["QUERY"]}"
				when :md5
					pd.logMessage "MD5 on row #{current_row_number} yielded no hits: #{row["MD5"]}"
				when :docid
					pd.logMessage "Document ID on row #{current_row_number} yielded no hits: #{row["DOCUMENT_ID"]}"
				when :guid
					pd.logMessage "GUID on row #{current_row_number} yielded no hits: #{row["GUID"]}"
				end
				next
			end

			# Resolve families if requested
			if include_families
				pd.setSubStatus("Resolving families...")
				relevant_items = iutil.findFamilies(relevant_items)
			end

			pd.setSubProgress(0,relevant_items.size)

			# Iterate every non-reserved column and apply custom metadata
			something_was_applied = false
			row.each do |header,value|
				next if reserved_column_names[header]
				if (value.nil? || value.strip.empty?) && apply_empty_values
					if header == "SetComment"
						pd.setSubStatusAndLogIt("Setting blank comment for #{relevant_items.size} items")
						relevant_items.each_with_index do |item,item_index|
							item.setComment("")
							pd.setSubProgress(item_index+1)
						end
					elsif header == "Custodian"
						pd.setSubStatusAndLogIt("Setting blank custodian for #{relevant_items.size} items")
						annotater.unassignCustodian(relevant_items) do |info|
							pd.setSubProgress(info.getStageCount)
						end
					else
						pd.setSubStatusAndLogIt("Applying '#{header}' with empty value to #{relevant_items.size} items")
						annotater.putCustomMetadata(header,"",relevant_items) do |info|
							pd.setSubProgress(info.getStageCount)
						end
					end
					something_was_applied = true
				elsif !value.nil? && !value.strip.empty?
					if header == "SetComment"
						pd.setSubStatusAndLogIt("Setting comment for #{relevant_items.size} items")
						relevant_items.each_with_index do |item,item_index|
							item.setComment(value)
							pd.setSubProgress(item_index+1)
						end
					elsif header == "AppendComment"
						pd.setSubStatusAndLogIt("Appending comment for #{relevant_items.size} items")
						relevant_items.each_with_index do |item,item_index|
							item.appendComment(value)
							pd.setSubProgress(item_index+1)
						end
					elsif header == "Custodian"
						pd.setSubStatusAndLogIt("Setting custodian '#{value}' for #{relevant_items.size} items")
						annotater.assignCustodian(value,relevant_items) do |info|
							pd.setSubProgress(info.getStageCount)
						end
					else
						pd.setSubStatusAndLogIt("Applying '#{header}' to #{relevant_items.size} items")
						annotater.putCustomMetadata(header,value,relevant_items) do |info|
							pd.setSubProgress(info.getStageCount)
						end
					end
					something_was_applied = true
				end
			end

			# Tag if was requested
			if values["tag_items"] && something_was_applied
				pd.setSubStatus("Tagging #{relevant_items.size} items...")
				annotater.addTag(tag_name,relevant_items) do |info|
					pd.setSubProgress(info.getStageCount)
				end
			end
		end

		pd.setMainStatusAndLogIt("Completed")
		pd.setSubStatus("")
		pd.setMainProgress(1,1)
		pd.setSubProgress(1,1)

		if values["tag_items"]
			$window.openTab("workbench",{:search => "tag:\"#{tag_name}\""})
		end
	end
end