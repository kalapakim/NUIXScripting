﻿Bulk Ingestron
==============

**Author:** Jason Wells

## Overview

This script provides a way to bulk ingest data into one or more cases.  Please read over the following documentation carefully to get a good sense of the various configuration options available.

## Settings Files

### ProcessingSettings.json

This is a JSON file containing the various ingestion settings to be used.  If a value is set to `null`, then Nuix will use its default values.  See API documentation for [Processor.setProcessingSettings][setProcessingSettings].

### ParallelProcessingSettings.json

This is a JSON file containing the various worker settings to be used.  If a value is set to `null`, then Nuix will use its default values.  See API documentation for [ParallelProcessingConfigurable.setParallelProcessingSettings][setParallelProcessingSettings].

### OcrSettings.json

This is a JSON file containing OCR settings which will be used if **performOcrPostIngestion** is set to `true` in [GeneralSettings.json].  If a value is set to `null`, then Nuix will use its default values.  See API documentation for [OcrProcessor.process](https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/OcrProcessor.html#process-java.util.List-java.util.Map-) for details on available settings.

### EvidenceSettings.json

This is a JSON file containing the evidence settings to use.  If a value is set to `null`, then Nuix will use defaults based on the current machine.

### GeneralSettings.json

This JSON file contains settings not specific to Nuix.

* **sleepBetweenJobs**: The number of seconds the script should wait after completing a job, before starting the next job.  This setting was added because in some situations worker licence release may take a moment.
* **ignoreUnknownMimeTypes**: This setting relates to how unknown mime types found in [MimeTypeSettings.csv] are handled.  When `true`, unknown mime types will log a warning but processing will proceed anyways.  When `false`, the script will intentionally halt before processing begins if unknown mime types are present in [MimeTypeSettings.csv].  The available mime types are checked against those which Nuix reports are available using a call to ```Utilities.getItemUtility.getAllTypes```.
* **allowCaseMigration**: When `true` you are giving Nuix permission to migrate older cases which may be opened by this script to the current version of Nuix running the script.  When `false` you are denying permission to Nuix to migrate cases.  If this is set to `false` and the case requires migration, the particular ingestion will be skipped.
* **additionalReportingScope**:  When ingestion completes, some numbers are gather and recorded regarding evidence total items, evidence audited items, etc.  These numbers are scoped to the evidence just added.  This setting allows you to specify additional scoping criteria in the form of a Nuix query.  This allows you to further excluded what items may be reported, for example to excluded certain kinds of error items.  If this value is `null` or empty, it has no effect.
* **performIngestion**: Allows you to turn off the ingestion step.  This setting is intended to be set to `false` only when `performOcrPostIngestion` is set to `true`.  The intended use is to allow you to run the script in an OCR only pass, using the same input file used to perform the ingestions.
* **performOcrPostIngestion**: Determines whether OCR will be performed against the items just ingested.  When `true` OCR will be performed.  When `false` no OCR will be performed.  Items which are OCR'ed when `true` will be limited to items present in the just added evidence and those responsive to the query provided in `postIngestionOcrQuery`.  Settings used to perform OCR are specified in the file [OcrSettings.json](#ocrsetting-json) and worker settings used are determined by those provided in [ParallelProcessingSettings.json](#parallelprocessingsettings-json).
* `postIngestionOcrQuery`: In addition to being scoped to the evidence just added, this query determines which items will be OCR'ed when `performOcrPostIngestion` is `true`.

### MimeTypeSettings.csv

This is a CSV in which you can specify settings for specific mime types.  The CSV contains the following columns:

- **Kind**: The particular kind, for reference only
- **LocalisedName**: The "friendly" name of the type, for reference only
- **PreferredExtension**: The commonly known extension for the type, for reference only
- **MimeType**: The mime type, should match values in Nuix
- **Enabled**: see below
- **ProcessEmbedded**: see below
- **ProcessText**: see below
- **TextStrip**: see below
- **ProcessNamedEntities**: see below
- **ProcessImages**: see below
- **StoreBinary**: see below

You can specify what will or will not be processed for various Mime Types by setting the relevant column to `true` or `false`.  For additional details about the last several columns refer to the API documentation for [Processor.setMimeTypeProcessingSettings][setMimeTypeProcessingSettings].

```:alert-info
**Note:** If a record is not present for a given type, nothing is set and Nuix will use it's defaults for that type (see API doc link above).
```

```:alert-danger
**Important:** When the script loads mime type settings from [MimeTypeSettings.csv](#mimetypesettings-csv) they will be checked against those present in your version of Nuix.  Depending on your configuration, unrecognized mime types will either be ignored or the script will halt.  See [GeneralSettings.json](#generalsettings-json) for details.
```

### SleepScheduleSettings.json

This is a JSON formatted file which contains information about when the script should sleep.  When the script detects the current time is within a scheduled sleep time it will enter an idle loop until the scheduled sleep time has ended.  The sleep schedule is checked at the following points during processing:

- Before starting the next job
- Before ingestion begins for a given job
- During ingest for a given job
- Before starting OCR for a given job
- During OCR of a given job

The default schedule settings specify no sleep times:

```javascript
{
	"sunday": {
		"sleep_start": "",
		"sleep_stop": ""
	},
	"monday": {
		"sleep_start": "",
		"sleep_stop": ""
	},
	"tuesday": {
		"sleep_start": "",
		"sleep_stop": ""
	},
	"wednesday": {
		"sleep_start": "",
		"sleep_stop": ""
	},
	"thursday": {
		"sleep_start": "",
		"sleep_stop": ""
	},
	"friday": {
		"sleep_start": "",
		"sleep_stop": ""
	},
	"saturday": {
		"sleep_start": "",
		"sleep_stop": ""
	}
}
```

To configure a sleep time for a given day, you must provide a time such as `6:00 AM` or `5:45 PM` in both `sleep_start` and `sleep_stop` for the given day.  Blank time values for either specify no sleep time for the given day.

Imagine you wished to setup the sleep schedule for the following:

- No sleeping on Saturday and Sunday (servers are available all day)
- Sleep 8:00 AM - 5:00 PM Monday thru Thursday (during office hours, servers are in use)
- Sleep 9:00 AM - 2:00 PM on Friday (shorter office hours so sleep time is shorter)

You could provided a JSON file like the following:

```javascript
{
	"sunday": {
		"sleep_start": "",
		"sleep_stop": ""
	},
	"monday": {
		"sleep_start": "8:00 AM",
		"sleep_stop": "5:00 PM"
	},
	"tuesday": {
		"sleep_start": "8:00 AM",
		"sleep_stop": "5:00 PM"
	},
	"wednesday": {
		"sleep_start": "8:00 AM",
		"sleep_stop": "5:00 PM"
	},
	"thursday": {
		"sleep_start": "8:00 AM",
		"sleep_stop": "5:00 PM"
	},
	"friday": {
		"sleep_start": "9:00 AM",
		"sleep_stop": "2:00 PM"
	},
	"saturday": {
		"sleep_start": "",
		"sleep_stop": ""
	}
}
```


## Input File

Input CSV is expected to have a headers row.  It is also expected to have the following columns in the following order:

- **Case Name**: What to name the case if it needs to be created.
- **Case Directory**: The directory of the case to use.  If the case does not exist it will be created.  If the case does exist it will be opened.
- **Evidence Name**: Name of the evidence to be created.
- **Evidence Comments**: Comments which will be applied to the evidence container item.
- **Custodian**: The custodian to assign to the evidence.
- **Source Path**: The path to the source data.  If this is a directory Nuix will ingest all data in the directory.  If this is a absolute file path, just the file will be processed.
- **Optional Additional Columns**: Any additional columns are added as custom metadata to the evidence container using the headers as the custom metadata name and cell value as the value.

You can specify multiple paths for a single evidence by separating the paths in **Source Path** with a `;`

```
C:\path1;C:\path2;C:\path3
```

```:alert-info
See `SampleInput.csv` included with this script for an example input file.
```

## Output Files

While running three files are created and updated, named with a timestamp.

- All output written to standard out will also be logged to a log file `{TIMESTAMP}_Log.txt`
- After each individual ingestion job is completed it will either be recorded to the error report or the success report depending on whether there were any errors.

```:alert-warning
**IMPORTANT**: Do not open the output CSV files until the script completes as this could cause a file permissions error!
```

### Error Report

`{TIMESTAMP}_Errored.csv`

- Case Name
- Case Directory
- Evidence Name
- Evidence Comments
- Custodian Name
- Source Path
- *.. Any Custom Metadata Columns You Defined ...*
- Error Message

### Success Report

`{TIMESTAMP}_Successful.csv`

- Case Name
- Case Directory
- Evidence Name
- Evidence Comments
- Custodian Name
- Source Path
- *.. Any Custom Metadata Columns You Defined ...*
- Total Item Count
- Total Emails Count
- Total Audited Item Count
- Total Audited Size GB
- Total OCR Items
- Ingestion Elapsed
- OCR Elapsed
- Total Elapsed

## Change Log

### v1.9
2016/06/09

- Modified default OCR value for `postIngestionOcrQuery` in `GeneralSettings.json` to be `-content:*` as suggested in Nuix 7 changelog as the way to query for items without text.
- Ocr settings now reported to log if OCR will be performed
- Further tweaks to progress reporting interval logic.  Hopefully this will prevent erroneous progress reporting during OCR which was occurring in v1.8.

### v1.8
2016/06/06

- Increased default `brokerMemory` value from `768` to `4096` in `ParallelProcessingSettings.json` to match the default documented in Nuix 7.
- OCR progress messages are now logged every `15` minutes or every `5000` items.
- Ingestion progress messages are now logged every `5000` items

### v1.7
2016/02/19

- Reinstated some sleep schedule checks that were commented out from previous testing

### v1.6
2016/02/01

- **Added sleep schedule system**  
Allows for specifying days and times in which the script will go to sleep (enter an idle loop).  See [SleepScheduleSettings.json](#sleepschedulesettings-json) for more information.

### v1.5
2015/09/02

- **May run OCR only now**  
Added the setting `performIngestion` to [GeneralSettings.json].  The purpose of this setting is to allow you to first run a series of ingestions with `performIngestion` set to `true` and `performOcrPostIngestion` set to `false`.  Then later you can set `performIngestion` to `false` and `performOcrPostIngestion` to `true`, allowing you to use the same input file to perform an OCR only run against the same set of cases.
- **Input file now supports evidence comments**  
The input file now is expected to contain a column `Evidence Comments` after `Evidence Name`.  The value present in this field will be applied as comments to the evidence item.  `Evidence Comments` is now also reported to the error and success reports.

### v1.4.1
2015/08/27

- **Fixed error when performing OCR and no OCR candidates are found**  
Script would attempt to perform OCR regardless of whether items to be OCR'ed were located.  The script now checks how many items were found and skips the rest of the OCR process for the given ingestion if the count is less than 1.
- **Elapsed times now recorded in success report**  
The script now records the time elapsed for ingestion, ocr and total per ingestion job.
- **OCR item count now recorded in success report**

### v1.4
2015/08/25

- **Reported counts now scoped to just added evidence**  
Report counts post ingestion are now scoped to the evidence just added as well as by an optional user provided scope query determined by `additionalReportingScope` in [GeneralSettings.json].  Previous to this change each time these values were reported it would be for the entire case.  If you were to add multiple evidence to a single case, these reported numbers would always be cumulative values rather than just the values of the evidence just added.
- **Added support for performing OCR post ingestion**  
See settings `performOcrPostIngestion` and `postIngestionOcrQuery` for the settings file [GeneralSettings.json].  Also see [OcrSettings.json].
- **Whitespace stripped from source path before being added to evidence container**

### v1.3.2
2015/08/14

- **Added setting `allowCaseMigration` to [GeneralSettings.json]**  
This setting allows you to configure whether Nuix is allowed to migrate a case created in a previous version when opening it to perform processing.

### v1.3.1
2015/08/13

- **Added a defensive version check around acquisition of Processor object**  
If detected version of Nuix is less than 6.2, the now deprecated `getProcessor` method is used instead of the now preferred `createProcessor` method.  This should allow the script to work in versions prior to 6.2 while behaving in the preferred manner in newer versions.

- **Only configure non default mime types**  
When configuring the processor this will now only configure mime type settings for entries in [MimeTypeSettings.csv] which have been modified from the default values.

- **Mime types are checked against Nuix internal listing before processing**  
The script now verifies mime types present in [MimeTypeSettings.csv] while loading them.  If any mime types are found which are not reported to be known by Nuix, the script will either log warnings about this and proceed, or halt.  To configure this behavior, see documentation for [GeneralSettings.json] above.

- **Added `ignoreUnknownMimeTypes` setting to [GeneralSettings.json]**  
This determines how unrecognized mime types in [MimeTypeSettings.csv] are handled.  See documentation for [GeneralSettings.json] above.

### v1.3
2015/08/13

- **Added `sleepBetweenJobs` setting and [GeneralSettings.json].**  
This allows you to specify a time in seconds that the script should wait before starting the next ingestion job.  It was reported that in some cases such as when using a VM, the workers may take a moment to free up for the next job.
- **Added reporting of Nuix version, requested workers and availabled workers**  
Some additional logging for debugging purposed.  Note that available workers is only reported when ran in Nuix 6.2 or higher.
- **Only non default mime type settings reported**  
Previous versions of the script which supported mime type settings reported all the settings.  This now only reports the mime type settings which were modified.
- **Support for multiple source paths**  
You can now specify multiple source paths in the **Source Path** column of the input file by separating multiple paths using a `;`.
- **Broke out classes into multiple files**  
This is mostly an implementation detail.  Code was beginning to get unruly for a single file.
- **Added support for evidence custom metadata**  
Now additional columns are added to evidence containers as custom metadata.
- **Logs are now written to a sub directory `Logs`**  
Keeps the main script directory a little less cluttered.
- **Fixed some pathing to be less OS specific**  
For resources the script would load from a local file path, such as settings files, `\` slashes were being used.  Now uses `File.join` to make the generation of these paths less OS specific.  This is a script implementation detail and has no effect on input file pathing.

### v1.2
2015/08/06

### v1.1
2015/05/22

### v1.0
2015/01/20

[setProcessingSettings]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Processor.html#setProcessingSettings-java.util.Map-
[setParallelProcessingSettings]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ParallelProcessingConfigurable.html#setParallelProcessingSettings-java.util.Map-
[setMimeTypeProcessingSettings]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Processor.html#setMimeTypeProcessingSettings-java.lang.String-java.util.Map-
[GeneralSettings.json]: #generalsettings-json
[MimeTypeSettings.csv]: #mimetypesettings-csv
[OcrSettings.json]: #ocrsettings-json