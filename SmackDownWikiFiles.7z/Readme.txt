Hello Nuix Developer Day 2016 participant!  Thank you for attending.  As always I enjoyed talking with you all.

Here are the Markdown files used to produce the Wiki made available during the Scripting SmackDown.  If you are unfamiliar with Markdown format I suggest you do a quick search on the web, but basically Markdown is a convenient documentation short hand often used to produce HTML.

The best way to reproduce this as a Wiki again is to create your own Github Repository with a Wiki and upload the provided Markdown files as the contents.

You might also research tools which are able to convert Github wiki Markdown files into your destination format of choice.  In general any Markdown conversion tool will work for the most part, but for all the hyperlinks to convert correctly you will want to use a tool which understands the Github Markdown link format.

I hope to see you again next year at the Nuix Developer Day!

- Jason Wells <jason.wells@nuix.com>