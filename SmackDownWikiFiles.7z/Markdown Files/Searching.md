﻿- [Searching with the API](#searching-with-the-api)
- [Getting the Count of Items Responsive to a Query](#getting-the-count-of-items-responsive-to-a-query)
- [Getting the Items Responsive to a Query](#getting-the-items-resposive-to-a-query)
- [Advanced Searching](#advanced-searching)
  - [Limiting Search Results](#limiting-search-results)
  - [Default Search Fields](#default-search-fields)

This section does not go into the query syntax or query fields supported by Nuix.  Please refer to the following documentation for more details on search queries:

- [Search Query Syntax](https://download.nuix.com/releases/desktop/stable/docs/en/search/syntax.html)
- [Search Fields](https://download.nuix.com/releases/desktop/stable/docs/en/search/fields.html)

# Searching with the API

Searches run through the API are not subject to some of the additional manipulations which would be performed were you to run the same search through the GUI.  Searches run through the API do **NOT** automatically have excluded items removed.  Searches run through the API also do **NOT** apply the default fields specified in the *Global Options* of the GUI (although you can use the [appropriate method](#default-seaqrch-fields) to simulate this in Nuix 7.0 an up).

If you wish for similar behavior when searching through the API, you must modify your query to contain similar logic (such as `has-exclusion:0`) or manipulate the results afterwards.  For more information on how to manipulate search results, see [[Working with Item Collections]].

# Getting the Count of Items Responsive to a Query

The simplest form of searching is just getting a count of items which are responsive to a query.  This can be performed using the [Case.count] method:

```ruby
# Define the query we will run
query = "flag:audited"

# Get the responsive item count and store in hit_count
hit_count = $current_case.count(query)

# Display the hit count to the user
puts "Hits: #{hit_count}"
```

Additionally since this form of searching does not return the actual items, it tends to perform faster that a full search using [Case.search].

# Getting the Items Responsive to a Query

More often you will want to actually inspect and use the items responsive to a search.  This is especially true if you wish to perform actions such as tagging, exporting, etc.

To get the items responsive to a query, you can use the [Case.search] method:

```ruby
# Define the query we will run
query = "flag:audited"

# Run the search and store the responsive items
items = $current_case.search(query)

# Display the hit count to the user
puts "Hits: #{items.size}"

# Iterate all the items
items.each do |item|
	# Display the name of each responsive item
	puts item.getName
end
```

# Advanced Searching

## Limiting Search Results

You may have a use can where you only wish to get the first N number of hits.  You can do this using a special overload of the search method [Case.search(queryString,options)], which not only accepts a query string but also a [Hash](Ruby-Basics.html#hash) (known as a [Map](https://docs.oracle.com/javase/8/docs/api/java/util/Map.html) in Java) of additional options.

```ruby
search_options = {
	"limit" => 100,
}
items = $current_case.search("cat",search_options)
```

This also has an intersting secondary use case.  When you wish to test whether a query is valid without actually running the search you can set `limit` to `0`.

```ruby
search_options = {
	"limit" => 0,
}

# Need an exception catch if the query has an error (often a good practice anyways)
begin
	items = $current_case.search("cat",search_options)
rescue Exception => exc
	puts "Error in query: #{exc.message}"
end
```

## Default Search Fields

Beginning in Nuix 7.0 you can now specify default fields for terms without an explicit field name specified,  similiar to if you were to set them using **Global Options** in the GUI.

```ruby
search_options = {
	"defaultFields" => ["name","content"]
}
items = $current_case.search("cat",search_options)
```

When providing your own set of default search fields, you want to make sure you provide at least one default field.  If you provide no default fields calling this search method, any terms in your query which do not explictly define a field will not contribute to your search!

For example:

```ruby
query = "query"

# Search on field name and content by default
search_options = {
    "defaultFields" => ["name","content"]
}
items = $current_case.search(query,search_options)
puts "Hits: #{items.size}"
# => 37

search_options = {
    "defaultFields" => []
}
items = $current_case.search(query,search_options)
puts "Hits: #{items.size}"
# => 0

search_options = {
    "defaultFields" => []
}
items = $current_case.search(query,search_options)
puts "Hits: #{items.size}"
# => 0
```


[Case.search(queryString,options)]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Case.html#search-java.lang.String-java.util.Map-
[Case.count]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Case.html#count-java.lang.String-
[Case.search]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Case.html#search-java.lang.String-