- [Anatomy of an API Method](#anatomy-of-an-api-method)
  - [Available with Feature](#available-with-feature)
  - [Method Signature](#method-signature)
    - [Translating Java Type to Ruby Types](#translating-java-types-to-ruby-types)
  - [Description](#description)
  - [Parameters](#parameters)
  - [Throws](#throws)
  - [Since](#since)

Being comfortable with reading the Nuix API documentation can be very helpful when writing scripts or debugging a script's behavior.  Since Nuix is written in Java, the API documentation relates to the various API calls using Java.  It can be difficult to translate how Java terminology relates to your Ruby script.  The goal of this section is to help you better understand the API documentation from a Ruby perspective.

# Anatomy of an API Method

I'm going to use the documentation for [ItemSet.addItems] in the following examples because it demonstrates several characteristics of interest.

## Available with Feature

The entry for [ItemSet.addItems] starts off with this line:

```code
@AvailableWithFeature(value="ANALYSIS")
```

As you might have guessed this specifies what feature your licence must have to make this API call.  In the above example, you will need to have a licence which has the feature `ANALYSIS`.

Sometimes you will instead see:

```code
@AvailableWithAnyLicence
```

Which specifies the given API call is available to all licence types.

So how do you determine whether your licence has the required feature?  If you know what type of licence you are using you may refer to the [Licence Feature Matrix](https://download.nuix.com/releases/desktop/stable/docs/en/reference/licence-profiles.html), which outlines each feature and which licence types have each feature.

You can also leverage the API to help you determine this.  The API has the [Licence] object which contains information about the current licence.  The [Licence] object has the method [Licence.hasFeature] which you can use to test whether the current licence contains a specific feature.

You obtain the [Licence] object from the [Utilities] object by calling [Utilities.getLicence].  You then call [Licence.hasFeature] to determine whether the current licence has a particular feature.

```ruby
# Test whether our licence has the feature "ANALYSIS"
# Obtain the licence object
current_licence = $utilities.getLicence
has_analysis_feature = current_licence.hasFeature("ANALYSIS")
if has_analysis_feature
	puts "Your licence has the feature 'ANALYSIS'"
else
	puts "Your licence does not have the feature 'ANALYSIS'"
end
```

This can be helpful if you expect your script to potentially be run under different licences, as you may be able to disable features of your script at run-time (which would otherwise cause an error) by checking the currently available features.

## Method Signature

The next entry you will see for [ItemSet.addItems] is the method signature:

```java
void addItems(java.util.Collection<Item> items, java.util.Map<?,?> options)
```

- `void` specifies that this method returns no value
- `addItems` is the name of the method
- `java.util.Collection<Item> items` states that this method accepts a [java.util.Collection] of Nuix [Items](WorkingWithItems.html) as the first argument
- `java.util.Map<?,?> options` states that this method takes a [java.util.Map] of options as the second arguments

### Translating Java types to Ruby Types

When you see an argument or return value specifying [java.util.Map], it will behave as a [Ruby Hash] as far as your script is concerned.

If a method returns or accepts one of the following Java types you can usually treat it as though it were a [Ruby Array]:
- [java.lang.Iterable]: You cannot access a specific index and the total size is unknown.  This is mostly only relevant, as far as the Nuix API is concerned, when dealing with the results of calling [Case.getHistory].
- [java.util.Collection]: Like [java.lang.Iterable] you cannot access the element at a specific index.  Unlike [java.lang.Iterable] the size is known.  It is implied that the elements have no specific order.
- [java.util.Set]: A collection that contains no duplicate elements.  Whether two elements are duplicates is essentially determined by whether `element_a == element_b` evaluates to `true`.  To be more specific, it is based on the `equals` method on the objects being compared.  To quote Java's documentation for [java.util.Set]:  
`sets contain no pair of elements e1 and e2 such that e1.equals(e2), and at most one null element`
For an example of the `equals` method in the Nuix API, see [Item.equals].
- [java.util.List]: It has a known size, you can access elements by index, it can contain duplicate elements and the elements are in a specific order.

You might be saying to yourself, "Why do I need to know this, I'm writing a Ruby script".  Lets say you run a search and now you would like to have Nuix deduplicate the results and then export their text.  The method [ItemUtility.deduplicate] can provide deduplication and to perform the export you eventually call [BatchExporter.exportItems].

```ruby
# Search for some items
items = $current_case.search("flag:audited")
# Deduplicate the items
deduped_items = $utilities.getItemUtility.deduplicate(items)
# Obtain a batch exporter
exporter = $utilities.createBatchExporter("C:\\Temp\\Exports\\123")
# Add the 'text' product to the export
exporter.addProduct("text",{"naming" => "guid"})
# Begin exporting
exporter.exportItems(deduped_items)
```

This example seems like it should work, but I expect you should get an error like the following:

```
NameError: no method 'exportItems' for arguments (com.sun.proxy.$Proxy65) on Java::Default::$Proxy75
  available overloads:
    (java.util.List)
    (nuix.ProductionSet)
... ETC ...
```

The problem is [BatchExporter.exportItems] expects a `List` of items but [ItemUtility.deduplicate] returns a `Set` of items.  While the solution is simple, it is useful to know why you may be having an issue such as this.

To remedy the problem, call `to_a` on the `Set`:

```ruby
# Search for some items
items = $current_case.search("flag:audited")
# Deduplicate the items
deduped_items = $utilities.getItemUtility.deduplicate(items)
# Since 'deduped_items' is currently a java.util.Set of items
# we call 'to_a' to convert it to a Ruby Array, which is essentially
# a java.util.List internally
deduped_items = deduped_items.to_a #
# Obtain a batch exporter
exporter = $utilities.createBatchExporter("C:\\Temp\\Exports\\123")
# Add the 'text' product to the export
exporter.addProduct("text",{"naming" => "guid"})
# Begin exporting
exporter.exportItems(deduped_items)
```

A Nuix API method which accepts a [java.util.Collection] of items, implies that the method is not concerned about the order of the items.  Additionally a method which accepts a [java.util.Collection] of items will also accept a [java.util.Set] of items or a [java.util.List] of items as these are both more derived (more specific) forms of [java.util.Collection].

A Nuix API method which accepts a [java.util.List] of items implies that it may be important what order the [java.util.List] of items is in and you may want to consider sorting the items before providing them to the given method.

## Description

The next entry in [ItemSet.addItems] is the description.  Reading this will usually provide you important details to how the method works, including any settings the method accepts and what the defaults may be if a given setting is not provided.

## Parameters

This section contains brief descriptions of what is expected as input to the method.

## Throws

This section outlines the potential errors the method may "throw" and what conditions are likely to cause the erorrs.  If you are having an error calling an API method, this can often explain why.

## Since

This tells you what version of the API the given method became available in the API.  This is very useful when developing a script which may be run under different versions of Nuix.  See [Nuix Version Checking](RubySnippets.html#nuix-version-checking) for code that can assist in creating scripts that can work against different versions of Nuix.

[ItemSet.addItems]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemSet.html#addItems-java.util.Collection-java.util.Map-
[Licence]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Licence.html
[Licence.hasFeature]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/LicenceProperties.html#hasFeature-java.lang.String-
[Utilities]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Utilities.html
[Utilities.getLicence]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Utilities.html#getLicence--
[Licence]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Licence.html
[Ruby Array]: RubyBasics.html#array
[Ruby Hash]: RubyBasics.html#hash
[Case.getHistory]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Case.html#getHistory--
[Item.equals]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Item.html#equals-nuix.Item-
[java.util.Map]: https://docs.oracle.com/javase/8/docs/api/java/util/Map.html
[java.lang.Iterable]: https://docs.oracle.com/javase/8/docs/api/java/lang/Iterable.html
[java.util.Collection]: https://docs.oracle.com/javase/8/docs/api/java/util/Collection.html
[java.util.Set]: https://docs.oracle.com/javase/8/docs/api/java/util/Set.html
[java.util.List]: https://docs.oracle.com/javase/8/docs/api/java/util/List.html
[ItemUtility.deduplicate]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemUtility.html#deduplicate-java.util.Collection-
[BatchExporter.exportItems]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/BatchExporter.html#exportItems-java.util.List-