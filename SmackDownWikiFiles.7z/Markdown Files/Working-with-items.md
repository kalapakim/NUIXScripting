﻿- [Name](#name)
- [Date](#date)
- [Type and Kind](#type-and-kind)
- [Digests](#digests)
- [Communication](#communication)
- [Related Items](#related-items)
  - [Root Items](#root-items)
  - [Top Level Item](#top-level-item)
  - [Parent Item](#parent-item)
  - [Duplicates](#duplicates)
  - [Near Duplicates](#Near Duplicates)
  - [Children](#children)
  - [Descendants](#descendants)
  - [Family](#family)
  - [Item Path](#item-path)
- [Properties](#properties)
- [Annotating Items](#annotating-items)

In Nuix the [Item] object is the basic unit of data which represents folders, files, emails, etc.

# Name

You can get the name of an item using [Item.getName].  If an item has no name this will return an empty string.

```ruby
items = $current_case.search("")
items.each do |item|
	puts item.getName
end
```

When an item has no name in Nuix, Nuix substitutes a placeholder name such as `[Unnamed Image]`.  If you wish to have the same behaviour when gettting an item's name, instead use [Item.getLocalisedName] which will return a localised placeholder name for items without a name.

# Date

Nuix calculates for each item a special date value based on some logic.  To quote [the documentation for Item Date](https://download.nuix.com/releases/desktop/stable/docs/en/reference/special-metadata.html):

> The date of the item. Derived from the communication date, or if the communication date is not present, the last modification date, or finally the creation date.

To get the "Item Date" for an item, use [Item.getDate].

```ruby
items = $current_case.search("")
items.each do |item|
	puts "The date of #{item.getName} is #{item.getDate}"
end
```

This will return a [org.joda.time.DateTime](http://joda-time.sourceforge.net/apidocs/org/joda/time/DateTime.html) Java object.

# Type and Kind

During ingestion of data, Nuix will identify data and assign a particular [ItemType] to each item.  Each [ItemType] has an associated [ItemKind].  [ItemType] being the specific type identified (i.e. mime type) and [ItemKind] is a broader category to which that kind belongs (e.g. image, email, container, etc).

You can get the type determined for an item by calling [Item.getType].  In turn you may call the various methods present on [ItemType] to get details about the determined type, including the type's [ItemKind].

```ruby
items = $current_case.search("")
items.each do |item|
	item_type = item.getType
	puts "Mime Type: #{item_type.getName}"
	puts "Friendly Type Name: #{item_type.getLocalisedName}"
	puts "Preferred Extension: #{item_type.getPreferredExtension}"
	item_kind = item_type.getKind
	puts "Kind: #{item_kind.getName}"
end
```

For a PDF this might print:

```code
Mime Type: application/pdf
Friendly Type Name: Portable Document Format
Preferred Extension: pdf
Kind: document
```

# Digests

Depending on the [processing settings](https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Processor.html#setProcessingSettings-java.util.Map-) you use, Nuix may calculate the following digests for most items:

- MD5
- SHA-1
- SHA-256

You may access the value of these digests for an item using [Item.getDigests] which returns a [DigestCollection] object containing the digest values (if present) and the size in bytes of the data used to calculate the digests.

```ruby
# Obtain some items
items = $current_case.search("")
# Iterate each item
items.each do |item|
	# Get the item's digests collection
	digests = item.getDigests
	# Get the MD5 or a fallback if missing
	md5 = digests.getMd5 || "Item has no MD5"
	# Get the SHA-1 or a fallback if missing
	sha1 = digests.getSha1 || "Item has no SHA-1"
	# Get the SHA-256 or a fallback if missing
	sha256 = digests.getSha256 || "Item has no SHA-256"
	
	puts "Name: #{item.getName}"
	puts "MD5: #{md5}"
	puts "SHA-1: #{sha1}"
	puts "SHA-256: #{sha256}"
end
```

It is important to note that if a given item does not have a particular digest, the corresponding "get" digest method will return [nil].

# Communication

Some items, such as emails, have an associated [Communication] object containing information relevant to the item such as:

- From addresses
- To addresses
- CC addresses
- BCC addresses
- Time of Communication

You can get the associated [Communication] object of an item (if it has one) using [Item.getCommunication].  If an item does not have an associated [Communication] object, this will return [nil].

The [Communication] object in turn has several methods for obtaining a list of [Address] objects for each address field:

- [Communication.getFrom]
- [Communication.getTo]
- [Communication.getCc]
- [Communication.getBcc]

And [Communication.getDateTime] for getting the communication's date and time.

Each [Address] in turn has several methods for obtaining different representations of the address value.

```ruby
# Obtain some items
items = $current_case.search("")
# Iterate each item
items.each do |item|
	# Get the communication object for this item
	communication = item.getCommunication
	# If this item has no communication object this will be nil
	# Its could practice to check for this to prevent script errors
	if communication.nil?
		puts "Item #{item.getName} does not have a communication"
	else
		puts "Name: #{item.getName}"
		puts "Date: #{communication.getDateTime}"
		# Print each From address display string
		puts "From:"
		communication.getFrom.each do |address|
			puts "\t#{address.toDisplayString}"
		end
		# Print each To address display string
		puts "To:"
		communication.getTo.each do |address|
			puts "\t#{address.toDisplayString}"
		end
		# Print each CC address display string
		puts "CC:"
		communication.getCc.each do |address|
			puts "\t#{address.toDisplayString}"
		end
		# Print each BCC address display string
		puts "BCC:"
		communication.getFrom.each do |address|
			puts "\t#{address.toDisplayString}"
		end
	end
end
```

# Related Items

Any given item in Nuix may have various relationships with other items including:
- Evidence container item (its root item)
- Top level item
- Parent item
- Duplicate items
- Near duplicate items
- Child items (immediate descendants)
- Descendant items
- Family (items have the same top level item)

## Root Item

An item's root item is the evidence container item that contains it.  You can get an item's root item using [Item.getRoot].

```ruby
items = $current_case.search("")
items.each do |item|
	puts "#{item.getName} is in evidence #{item.getRoot}"
end
```

## Top Level Item

You can get the top level item of a given item using [Item.getTopLevelItem].  If an item is above "top level", this will return [nil].

```ruby
items = $current_case.search("")
items.each do |item|
	top_level_item = item.getTopLevelItem
	if top_level_item.nil?
		puts "Item is above top level"
	else
		puts "#{top_level_item.getName} is the top level item of #{item.getName}"
	end
end
```

If you are looking to resolve multiple items to their corresponding top level items you are better off using [ItemUtility.findTopLevelItems].  See [[Working with Item Collections]] for more details.

## Parent Item

You can get the parent item using [Item.getParent].  If the item is an evidence container item (root item) then this will return [nil].

```ruby
items = $current_case.search("")
items.each do |item|
	parent_item = item.getParent
	if top_level_item.nil?
		puts "Evidence container items have no parent"
	else
		puts "The parent of #{item.getName} is #{parent_item.getName}"
	end
end
```

## Duplicates

You can find the items which are duplicates of a given item using [Item.getDuplicates].

```ruby
items = $current_case.search("")
items.each do |item|
	duplicate_items = item.getDuplicates
	puts "#{item.getName} has #{duplicate_items.size} duplicates"
end
```

The [ItemUtility] object provides similar functionality when you wish to resolve the duplicates of multiple items at once.  See [[Working with Item Collections]] for more details.

## Near Duplicates

You can find the items which are near duplicates of a given item using [Item.getNearDuplicates].  When calling [Item.getNearDuplicates] you provide a resemblence value between 0.0 and 1.0, with 1.0 representing items which have exact shingle sets.

```ruby
items = $current_case.search("")
resemblence = 0.75
items.each do |item|
	near_duplicate_items = item.getNearDuplicates
	puts "#{item.getName} has #{near_duplicate_items.size} duplicates which are at least 75% similar"
end
```

If you wish to determine how similar another item is, you can use [Item.resemblenceTo] which will return a value between 0.0 and 1.0, with 1.0 representing that the two items have exact shingle sets.

## Children

An item's children are the direct descendants of the item, such as the attachments to an email but not the attachments' descendants.  You can get the children of an item using [Item.getChildren].

```ruby
items = $current_case.search("")
items.each do |item|
	child_items = item.getChildren
	puts "#{item.getName} has #{child_items.size} children"
end
```

## Descendants

An item's descendants are all the items "beneath" a given item (item's chilren, childrens' children, and so on).  You can get all the descendants of an item using [Item.getDescendants].

```ruby
items = $current_case.search("")
items.each do |item|
	descendant_items = item.getDescendants
	puts "#{item.getName} has #{descendant_items.size} descendants"
end
```

The [ItemUtility] object provides similar functionality when you wish to resolve the descendants of multiple items at once.  See [[Working with Item Collections]] for more details.

## Family

Items which are all descendants of the same top level item are a family.  You can get the members of the family an item belongs to using [Item.getFamily].  Since this relates to the top level item, if the item is above top level, this will return [nil].

```ruby
items = $current_case.search("")
items.each do |item|
	family_items = item.getChildren
	if family_items.nil?
		puts "#{item.getName} is above top level"
	else
		puts "#{item.getName} belongs to a family with #{family_items.size} items"
	end
end
```

The [ItemUtility] object provides similar functionality when you wish to resolve the families of multiple items at once.  See [[Working with Item Collections]] for more details.

## Item Path

Sometimes you want the entire path of items from evidence container up to and include a given item.  You can get the items in the path using [Item.getPath].

```ruby
# Obtain items
items = $current_case.search("")
# Obtain the item sorter
sorter = $utilities.getItemSorter
# Sort items in position order
sorted_items = sorter.sortItemsByPosition(items)
# Iterate each item
sorted_items.each do |item|
	# Get the path items for this item
	path_items = item.getPath
	# Map the path items to an array of their names
	path_names = path_items.map{|item| item.getLocalisedName }
	# Join the path names into a single string, separaterd by "/"
	path_name_string = path_names.join("/")
	# Print the path string
	puts path_name_string
end
```

```
Data 123
Data 123/Bob Smith.pst
Data 123/Bob Smith.pst/Content.Filter
Data 123/Bob Smith.pst/Top of Personal Folders
Data 123/Bob Smith.pst/Top of Personal Folders/Deleted Items
Data 123/Bob Smith.pst/Top of Personal Folders/Inbox
Data 123/Bob Smith.pst/Top of Personal Folders/Sent Items
Data 123/Bob Smith.pst/Top of Personal Folders/smith-b
Data 123/Bob Smith.pst/Top of Personal Folders/smith-b/Sent Items
Data 123/Bob Smith.pst/Search Root
Data 123/Bob Smith.pst/IPM_VIEWS
Data 123/Bob Smith.pst/IPM_COMMON_VIEWS
```

# Properties

Items have properties, which is metadata relevant to the specific item.  You obtain the properties of an item using [Item.getProperties].

```ruby
# Obtain items
items = $current_case.search("")
# Iterate each item
items.each do |item|
	# Print item name
	puts "[ #{item.getName} ]"
	# Get item properties
	item_properties = item.getProperties
	# Print each property name and value
	item_properties.each do |property_name,property_value|
		puts "\t#{property_name} = #{property_value}"
	end
end
```

```
[ Bob Smith.pst ]
	MS-DOS Read-only = false
	PST Encryption = Compressible
	MS-DOS Archive = true
	File Owner = BUILTIN\Administrators
	File Created = 2015-01-21T23:41:49.410Z
	PST Type = 2003
	Name = Kenneth Lay.pst
	File Modified = 2010-06-19T22:23:26.000Z
	MS-DOS System = false
	MS-DOS Hidden = false
	PST Name = lay-k_000
	File Accessed = 2015-01-21T23:41:49.410Z
	File Access Control List = [Ljava.lang.Object;@368bea1f
```

As far as your Ruby script is concerned, the result of calling [Item.getProperties] is a read only Ruby Hash.  Note that properties may be various data types, some of which do not automatically display well as string and therefore do not display well when displayed using `puts`.

# Annotating Items

The [Item] object has various ways to apply annotations such as:

- Custodian
- Comment
- Tags
- Custom Metadata

For more details on annotating items, see [[Annotations]].

[Item]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Item.html
[Item.getName]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemMetadata.html#getName--
[Item.getLocalisedName]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemMetadata.html#getLocalisedName-java.util.Locale-
[Item.getRoot]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Item.html#getRoot--
[Item.getTopLevelItem]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Item.html#getTopLevelItem--
[ItemUtility.findTopLevelItems]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemUtility.html#findTopLevelItems-java.util.Collection-
[Item.getParent]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemTreeNode.html#getParent--
[ItemUtility]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemUtility.html
[Item.getNearDuplicates]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Item.html#getNearDuplicates-float-
[Item.resemblenceTo]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Item.html#resemblanceTo-nuix.Item-
[Item.getChildren]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Item.html#getChildren--
[Item.getFamily]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Item.html#getFamily--
[Item.getDigests]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Item.html#getDigests--
[Item.getDate]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Item.html#getDate--
[DigestCollection]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/DigestCollection.html
[Communication]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Communication.html
[Item.getCommunication]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Item.html#getCommunication--
[Address]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Address.html
[Communication.getFrom]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Communication.html#getFrom--
[Communication.getTo]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Communication.html#getTo--
[Communication.getCc]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Communication.html#getCc--
[Communication.getBcc]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Communication.html#getBcc--
[Communication.getDateTime]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Communication.html#getDateTime--
[Item.getProperties]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemMetadata.html#getProperties--
[nil]: RubyBasics.html#nil
[Item.getPath]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemTreeNode.html#getPath--
[ItemType]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemType.html
[ItemKind]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemKind.html
[Item.getType]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemMetadata.html#getType--