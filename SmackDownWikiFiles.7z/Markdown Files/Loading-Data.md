- [Steps to Loading Data](#steps-to-loading-data)
- [Obtain the Processor](#obtain-the-processor)
- [Create Evidence Containers](#create-evidence-containers)
  - [Configure Evidence Container Settings](#configure-evidence-container-settings)
  - [Add Source Locations to the Evidence Container](#adding-source-locations-to-the-evidence-container)
  - [Save the Evidence Container](#save-the-evidence-container)
- [Configure the Processor](#configure-the-processor)
  - [Set Processing Settings](#set-processing-settings)
  - [Set Parallel Processing Settings](#set-parallel-processing-settings)
  - [SetMime Type Settings](#set-mime-type-settings)
- [Add Optional Callbacks](#add-optional-callbacks)
- [Begin Processing](#begin-processing)
- [Example Processing Script](#example-processing-script)

# Steps to Loading Data

Loading data into Nuix involves the following steps:

1. Obtain an instance of the [Processor] object
1. Using the [Processor] object, create an evidence container:
    1. Define things such as name, default encoding, default time zone
    1. Add one or more source locations (file path, directory path, online sources, etc)
    1. Save your changes!
1. Configure the settings used to process the data
1. Configure the worker settings used to process the data
1. Configure any callbacks you may want to use.  Callbacks are a way you can provide Nuix code which will be called at a particular step in a process, allowing you to do something such as report progress.
1. Begin processing

# Obtain the Processor

An instance of the [Processor] object can be obtained by calling [SimpleCase.createProcessor]:

```ruby
# Obtain a processor
processor = $current_case.createProcessor
```

If you are using a version of Nuix before 6.2.0 you will need to instead call the method [SimpleCase.getProcessor]:

```ruby
# Pre 6.2.0 obtain a processor
processor = $current_case.getProcessor
```

**Note:** The **getProcessor** method is deprecated in Nuix 6.2.0 and higher.  If available, favor usage of the **createProcessor** method instead.

# Create Evidence Containers

You enqueue data to be loaded by creating and configuring one or more [EvidenceContainer] objects.  With each [EvidenceContainer] you configure some evidence specific settings including:

* Evidence Name
* Default Time Zone
* Default Encoding
* Source Data Locations
* Initial Custodian
* Evidence Custom Metadata

You create a new evidence container to be processed by calling [Processor.newEvidenceContainer]:

```ruby
# Obtain a processor
processor = $current_case.createProcessor

# Define new evidence container name
evidence_name = "Data 123"

# Create a new evidence container 
evidence_container = processor.newEvidenceContainer(evidence_name)
```

## Configure Evidence Container Settings

Once you have create an [EvidenceContainer] you have some basic configuration to perform.

```ruby
# Set default encoding
evidence_container.setEncoding("UTF-8")

# Set default time zone
evidence_container.setTimeZone("US/Pacific")

# Set the default custodian name assigned to items in this evidence container
evidence_container.setInitialCustodian("Some Custodian Name")

# Set a description for this evidence container
evidence_container.setDescription("This is a description for my new evidence container")

# Add custom metadata to evidence container
additional_data = {
    "TrackingNumber" => 1234567890,
    "Matter" => "Cats vs Dogs",
    "SourceMedium" => "6 TB Hard Drive",
}
evidence_container.setCustomMetadata(additional_data)
```

## Add Source Locations to the Evidence Container

Once you have created your evidence container and performed basic configuration, you need to add one or more source locations to it.  The simplest form of adding a source location is by specifying the path to the data when calling [addFile](https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/EvidenceContainer.html#addFile-java.lang.String-).

```ruby
# Add a directory
evidence_container.addFile("C:\\Natives\\SourceData123")

# Add a file
evidence_container.addFile("C:\\Natives\\PSTs123\\Enron.pst")
```

**Note:** Nuix supports additional source types such as load files and network locations.  See the  API documentation for [EvidenceContainer](https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/EvidenceContainer.html) for a full listing.

## Save the Evidence Container

The final (but very important) step when creating an evidence container is to save it.  If you do not save your evidence container it will not be enqueued to be processed!  You save your [EvidenceContainer] by calling its [save](https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/EvidenceContainer.html#save--) method.

```ruby
# Save everything we have done
evidence_container.save
```

# Configure the Processor

## Set Processing Settings

You configure the processing settings by building a [[Ruby Hash|Ruby-Basics#hash]] containing the settings you would like to use and passing them to the [Processor] object by calling [Processor.setProcessingSettings].

```ruby
# Define our settings Hash
processing_settings = {
	"processText" => true,
	"traversalScope" => "full_traversal",
	"analysisLanguage" => "en",
	# Other settings here...
}

processor.setProcessingSettings(processing_settings)
```

Any settings which you do not explicitly set in your Hash will use Nuix defined defaults.  The full list of settings is beyond the scope of this document.  For a list of processing settings and their defaults, see the API documentation for [Processor.setProcessingSettings].

## Set Parallel Processing Settings

Similar to processing settings, to configure parallel processing settings you define a [[Ruby Hash|Ruby-Basics#hash]] with the settings then call [Processor.setParallelProcessingSettings].

```ruby
# Define our settings Hash
parallel_processing_settings = {
	"workerCount" => 8,
	"workerMemory" => 1024,
	"workerTemp" => "C:\\WorkerTemp",
}

processor.setParallelProcessingSettings(parallel_processing_settings)
```

Any settings which you do not explicitly set in your Hash will use Nuix defined defaults.  For a list of settings and their defaults, see the API documentation for [Processor.setParallelProcessingSettings].

**Note**: The `workerCount` setting is independent of how many workers you acquired with your licence at startup.  If you specify a `workerCount` value higher than what is available Nuix will adjust this to how many you actually have available.  If you set it lower, you will only use the number you specified.  If you do not set it at all, the default is based on the number of CPU cores present, not necessarily how many workers are available.  See the API documentation for [Processor.setParallelProcessingSettings](https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ParallelProcessingConfigurable.html#setParallelProcessingSettings-java.util.Map-) for more details.

## Set Mime Type Settings

The [Processor] object allows you to configure how specific mime types are handled during processing.  The Nuix API allows you to set the following settings for a given mime type (see API documentation for [Processor.setMimeTypeProcessingSettings])

<table class="table table-bordered">
<thead>
	<tr>
		<th>Setting</th>
		<th>Default</th>
		<th>Description</th>
	</tr>
</thead>
<tbody>
	<tr>
		<td><code>enabled</code></td>
		<td><code>true</code></td>
		<td>If <code>false</code> items matching this MIME type, and their embedded descendants, will not be processed.</td>
	</tr>
	<tr>
		<td><code>processEmbedded</code></td>
		<td><code>true</code></td>
		<td>If <code>false</code> descendants of items matching this MIME type will be processed.</td>
	</tr>
	<tr>
		<td><code>processText</code></td>
		<td><code>true</code></td>
		<td>If <code>false</code> items matching this MIME type will not have their text processed. <b>Note</b>: This setting cannot be used when <code>textStrip</code> is set for the same MIME type.</td>
	</tr>
	<tr>
		<td><code>textStrip</code></td>
		<td><code>false</code></td>
		<td>If <code>true</code> items matching this MIME type will have their binary data text stripped. <b>Note</b>: This setting cannot be used when <code>processText</code> is set for the same MIME type.</td>
	</tr>
	<tr>
		<td><code>processNamedEntities</code></td>
		<td><code>true</code></td>
		<td>If <code>false</code> items matching this MIME type will not have named entities extracted.</td>
	</tr>
	<tr>
		<td><code>processImages</code></td>
		<td><code>true</code></td>
		<td>If <code>false</code> items matching this MIME type will not have their image data processed.</td>
	</tr>
	<tr>
		<td><code>storeBinary</code></td>
		<td><code>true</code></td>
		<td>If <code>false</code> items matching this MIME type will not have their binary data stored. <b>Note</b>: This setting only takes effect if <code>storeBinary</code> is enabled in the global processing settings.</td>
	</tr>
</tbody>
</table>

The following is an example of configuring the settings for a given mime type.

```ruby
dll_mime_type = "application/dll"
dll_mime_type_settings = {
	"enabled" => false
}
processor.setMimeTypeProcessingSettings(dll_mime_type,dll_mime_type_settings)
```

Any mime type which you do not configure, will use the listed Nuix defaults.

**Note**: While these settings correspond to similar settings in the GUI, the API does not derive the defaults from the user's preferences!

# Add Optional Callbacks

An optional step is to add callbacks to the [Processor].  This allows your script to provide code which will be executed by Nuix in response to particular events.

The simplest example of this is the callback [Processor.whenItemProcessed].  You define a callback by providing a Ruby code block which will be passed an instance of [ProcessedItem] for each item which is processed.

```ruby
# Add callback for when an item is processed
processor.whenItemProcessed do |processed_item|
	puts "Mime Type: #{processed_item.getMimeType}"
end
```

As noted in the API documentation, this callback may be called by multiple threads.  So while you may be tempted to do something like the following:

```ruby
# Count how many items have been processed
processed_item_count = 0

processor.whenItemProcessed do |processed_item|
	processed_item_count += 1
	puts "Items Processed: #{processed_item_count}"
end
```

There can be some threading issues with the previous code example.  Most likely the value of `processed_item_count` will be incremented incorrectly due to multiple threads making changes to it at the same time.  There is also a potential issue with `puts` incorrectly writing out newlines.

This can be remedied with some thread synchronization:

```ruby
require 'thread'
semaphore = Mutex.new

# Count how many items have been processed
processed_item_count = 0

processor.whenItemProcessed do |processed_item|
	semaphore.synchronize {
		processed_item_count += 1
		# Show progress every 1000
		if processed_item_count % 1000 == 0
			puts "Items Processed: #{processed_item_count}"
		end
	}
end
```

The `semaphore.synchronize` block helps ensure that while the `whenItemProcessed` callback may be called on multiple threads at once, only one thread may enter the `semaphore.synchronize` block at a time.

# Begin Processing

Once you have created your evidence, configured your settings, and added any callbacks it is time to start processing.  This is done by calling [Processor.process].  Once called, execution of your script will not continue beyond this call until processing has completed.

```ruby
puts "About to begin processing..."

# Begin processing
processor.process

puts "Processing has completed"
```

# Example Processing Script

The following is the previous processing examples put together into a basic processing script.

```ruby
processor = $current_case.createProcessor
evidence_name = "Data 123"
evidence_container = processor.newEvidenceContainer(evidence_name)
evidence_container.addFile("C:\\@NUIX\\Natives\\EnronPSTs\\Kenneth Lay.pst")
evidence_container.save

#Define and configure processing settings
processing_settings = {
    "processText" => true,
    "traversalScope" => "full_traversal",
    "analysisLanguage" => "en",
    # Other settings here...
}
processor.setProcessingSettings(processing_settings)

#Define and configure parallel processing settings (for workers)
parallel_processing_settings = {
    "workerCount" => 8,
    "workerMemory" => 1024,
    "workerTemp" => "C:\\WorkerTemp",
}
processor.setParallelProcessingSettings(parallel_processing_settings)

#Example disabling a mime type
dll_mime_type = "application/dll"
dll_mime_type_settings = {
    "enabled" => false
}
processor.setMimeTypeProcessingSettings(dll_mime_type,dll_mime_type_settings)

require 'thread'
semaphore = Mutex.new
processed_item_count = 0
processor.whenItemProcessed do |event_info|
    semaphore.synchronize {
        processed_item_count += 1
        # Show progress every 1000
		if processed_item_count % 1000 == 0
			puts "Items Processed: #{processed_item_count}"
		end
    }
end
puts "About to begin processing..."
processor.process
puts "Processing has completed"
```

[ProcessedItem]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ProcessedItem.html
[Processor.newEvidenceContainer]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Processor.html#newEvidenceContainer-java.lang.String-
[Processor.process]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Processor.html#process--
[Processor.setParallelProcessingSettings]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ParallelProcessingConfigurable.html#setParallelProcessingSettings-java.util.Map-
[Processor.setProcessingSettings]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Processor.html#setProcessingSettings-java.util.Map-
[Processor.whenItemProcessed]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Processor.html#whenItemProcessed-nuix.ItemProcessedCallback-
[Processor]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Processor.html
[SimpleCase.createProcessor]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/SimpleCase.html#createProcessor-- 
[SimpleCase.getProcessor]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/SimpleCase.html#getProcessor--
[Processor.setMimeTypeProcessingSettings]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Processor.html#setMimeTypeProcessingSettings-java.lang.String-java.util.Map-
[EvidenceContainer]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/EvidenceContainer.html