﻿- [Using CSVs](#using-csvs)
  - [Reading from a CSV](#reading-from-a-csv)
  - [Writing to a CSV](#writing-to-a-csv)
- [String Manipulations](#string-manipulations)
  - [Interpolation](#interpolation)
  - [Join](#join)
  - [Find and Replace](#find-and-replace)
    - [Literal](#literal)
    - [Regular Expression](#regular-expression)

# Using CSVs

## Reading from a CSV

```ruby
# Need to load Ruby's CSV library
require "csv"

# Path to CSV
csv_path = "C:\\Path\\Input.csv"

# Iterate each record, first row will be skipped
CSV.foreach(csv_path,{:headers => :first_row}) do |row|
	# use each row here...
	col1 = row[0]
	col2 = row[1]
end
```

## Writing to a CSV

```ruby
# Need to load Ruby's CSV library
require "csv"

# Path to CSV
csv_path = "C:\\Path\\Output.csv"

CSV.open(csv_path,"w:utf-8") do |csv|
	# Write headers
	csv << ["Tag","Count"]
	# Write a record
	csv << ["Hit|Cat","42"]
end
```

# String Manipulations

## Interpolation

```ruby
name = "Jason"
greeting = "Hello #{name}"
puts greeting
```

**Output**

```
Hello Jason
```

## Join

```ruby
animals = [
	"cat",
	"dog",
	"mouse",
]

animals_or = animals.join(" OR ")
animals_and = animals.join(" AND ")
animals_piped = animals.join("|")

puts "ORed: #{animals_or}"
puts "ANDed: #{animals_and}"
puts "Piped: #{animals_piped}"
```

**Output**

```
ORed: cat OR dog OR mouse
ANDed: cat AND dog AND mouse
Piped: cat|dog|mouse
```

## Find and Replace

### Literal

```ruby
phrase = "This abacus is a quick way to make calculations"
updated_phrase = phrase.gsub("abacus","computer")
puts updated_phrase
```

**Output**

```
This computer is a quick way to make calculations
```

### Regular Expression

```ruby
regex = /ca[a-z]+/
phrase = "The cat drove the car into a canary"
updated_phrase = phrase.gsub(regex,"robot")
puts updated_phrase
```

**Output**

```
The robot drove the robot into a robot
```