- [Nuix Online Documentation](https://download.nuix.com/releases/desktop/stable/docs/en/index.html)  
The online documention for Nuix.
- [Nuix API Documentation](https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/index.html)  
The online API documentation for Nuix.
- [Nuix Developer Forums](http://forums.developer.nuix.com/)  
Forums where you can ask about and find answers to your custom development questions.
- [Calling Java from JRuby](https://github.com/jruby/jruby/wiki/CallingJavaFromJRuby)  
Various details about calling Java code from your Ruby code in JRuby.
- [JRuby](http://jruby.org/)  
The JRuby homepage.
- [Ruby Online Documentation](http://ruby-doc.org/)  
The online documentation for Ruby.