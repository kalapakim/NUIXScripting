In this wiki you will information to help you get going with custom development using Ruby and [Nuix].

- Getting Started
  - [[Setup]]
  - [[Running Your Script]]
  - [[Ruby Basics]]
  - [[JRuby Default Encoding]]
- Working with the API
  - [[Reading the API Documentation]]
  - [[Working with Cases]]
  - [[Loading Data]]
  - [[Worker Side Scripting]]
  - [[Searching]]
  - [[Working with Item Collections]]
  - [[Working with Items]]
  - [[Annotations]]
  - [[Item Sets]]
  - [[Exporting]]
- Other
  - [[Code Snippets]]
  - [[Reference Links]]

[Nuix]: http://www.nuix.com