- [Creating an Item Set](#creating-an-item-set)
- [Obtaining an Existing Item Set](#obtaining-an-existing-item-set)
- [Obtaining All Item Sets](#obtaining-all-item-sets)
- [Adding Items to an Item Set](#adding-items-to-an-item-set)

[Item sets][ItemSet] not only provide you a means by which you can group a collection of items, but also pre-calculate, scope and customize their deduplication.

# Creating an Item Set

A new item set can be created by calling the [Case.createItemSet] method.  When creating an item set you need to specify some settings in a Ruby Hash and provide them along with the name of the item set to be created.  See the API documentation for [Case.createItemSet] for more details on the available settings.

```ruby
item_set_name = "My Item Set"
item_set_settings = {
	"deduplication" => "MD5",
	"description" => "A new item set",
	"deduplicateBy" => "INDIVIDUAL",
}
item_set = $current_case.createItemSet(item_set_name,item_set_settings)
```

# Obtaining an Existing Item Set

You can obtain an existing item set by name using the [Case.findItemSetByName] method:

```ruby
item_set_name = "My Item Set"
item_set = $current_case.findItemSetByName(item_set_name)
```

# Obtaining All Item Sets

You can determine what item sets already exist by calling the [Case.getAllItemSets] method.  This will return a **Set** of [ItemSet] objects representing the items sets present in the given case.

```ruby
item_sets = $current_case.getAllItemSets
item_sets.each do |item_set|
	puts "Item Set Name: #{item_set.getName}"
end
```

# Adding Items to an Item Set

Items may be added to an existing item set by calling the [ItemSet.addItems] method.  When creating an item set you need to specify some settings in a Ruby Hash to provide to the method.  See the API documentation for [ItemSet.addItems] for more details.

```ruby
batch_settings = {
	"batch" => "Batch 123",
}
item_set_name = "My Item Set"
item_set = $current_case.findItemSetByName(item_set_name)
items = $current_case.search("tag:MyTag")
item_set.addItems(items,batch_settings)
```

[Case.createItemSet]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Case.html#createItemSet-java.lang.String-java.util.Map-
[Case.findItemSetByName]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Case.html#findItemSetByName-java.lang.String-
[Case.getAllItemSets]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Case.html#getAllItemSets--
[ItemSet]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemSet.html
[ItemSet.addItems]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemSet.html#addItems-java.util.Collection-java.util.Map-