﻿- [Exporting](#exporting)
  - [Traversal](#traversal)
  - [Adding Export Products](#adding-export-products)
    - [Example of Adding Natives](#example-of-adding-natives)
    - [Example of Adding Text Files](#example-of-adding-text-files)
    - [Example of Adding PDFs](#example-of-adding-pdfs)
  - [Adding Load Files](#adding-load-files)
  - [Set Parallel Processing Settings](#set-parallel-processing-settings)
  - [Export Numbering](#export-numbering)
    - [Generate Numbering](#generate-numbering)
    - [Production Set Based Numbering](#production-set-based-numbering)
  - [Add Optional Callbacks](#add-optional-callbacks)
  - [Beginning Export](#beginning-export)
    - [Export a List of Items](#export-a-list-of-items)
    - [Export a Production Set](#export-a-production-set)
    - [Export a Subset of a Production Set](#export-a-subset-of-a-production-set)
  - [Example Export Script](#example-export-script)
- [Single Item Exporters](#single-item-exporters)
  - [Basic Usage](#basic-usage)
  - [Single Item Exporter Variations](#single-item-exporter-variations)
    - [Binary Exporter](#binary-exporter)
    - [Email Exporter](#email-exporter)
    - [Mailbox Exporter](#mailbox-exporter)
    - [PDF Exporter](#pdf-exporter)
    - [Text Exporter](#text-exporter)
    - [Thumbnail Exporter](#thumnail-exporter)
    - [TIFF Exporter](#tiff-exporter)

# BatchExporter

Using the [BatchExporter] you are able to reproduce the functionality provided in the GUI by a legal export.

You obtain an instance of the [BatchExporter] from the [Utilities] object by calling [Utilities.createBatchExporter] and providing the directory path of where you want to export to.  If the specified directory does not exist, it will be created upon export.

```ruby
# Define the export root directory
export_location = "C:\\Exports\\Export123"
# Obtain an exporter
batch_exporter = $utilities.createBatchExporter(export_location)
```

## Traversal

By default the [BatchExporter] will export the items you provide it, in the order the items are provided, when you call [BatchExporter.exportItems](https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/BatchExporter.html#exportItems-java.util.List-) to beging the export process.  Using the method [BatchExport.setTraversalOptions] you are able to change this behavior.  This allows for including related items such as family members, performing deduplication and defining the order in which items should be exported, which can effect the numbering assigned to exported items.

```ruby
# Define our traversal settings
traversal_options = {
	"strategy" => "deduplicated_top_level_items_and_descendants",
	"deduplication" => "md5",
	"sortOrder" => "top_level_item_date",
}
# Set the traversal options
batch_exporter.setTraversalOptions(traversal_options)
```

For more details on the available settings see the API documentation for [BatchExport.setTraversalOptions].

## Adding Export Products

You add products to an export by calling the method [BatchExporter.addProduct].  This is how you specify exporting things like:

* Natives
* Text
* PDFs
* TIFFs
* XHTML Report
* Thumbnails

To add a product to be exported, you call [BatchExporter.addProduct] and provide the name of the product to be exported along with a Ruby Hash containing settings relevant to the product being exported.

### Example of Adding Natives

```ruby
# Define our native settings Hash
native_settings = {
	"naming" => "guid",
	"path" => "NATIVES",
	"mailFormat" => "msg",
	"includeAttachments" => true,
}
# Add natives to the export
batch_exporter.addProduct("native",native_settings)
```

### Example of Adding Text Files

```ruby
# Define our text settings Hash
text_settings = {
	"naming" => "guid",
	"path" => "TEXT",
	"lineSeparator" => "\n",
	"encoding" => "UTF-8",
}
# Add text files to the export
batch_exporter.addProduct("text",text_settings)
```

### Example of Adding PDFs

```ruby
# Define our PDF settings Hash
pdf_settings = {
	"naming" => "guid",
	"path" => "PDF",
	"regenerateStored" => true,
}
# Add PDFs to the export
batch_exporter.addProduct("pdf",pdf_settings)
```

For more details about the available settings see the API documentation for [BatchExporter.addProduct].

## Adding Load Files

You can add load files to your export export by calling [BatchExporter.addLoadFile], providing the name of the load file type and a Ruby Hash containing settings.

```ruby
# Define our load file settings Hash
load_file_settings = {
	"metadataProfile" => "Default metadata profile",
	"encoding" => "UTF-8",
}
# Add a concordance DAT load file to the export
batch_exporter.addLoadFile("concordance",load_file_settings)
```
For more details about the available settings see the API documentation for [BatchExporter.addLoadFile].

## Set Parallel Processing Settings

To configure parallel processing settings you define a Ruby Hash with the desired settings, then call [BatchExporter.setParallelProcessingSettings].

```ruby
# Define our settings Hash
parallel_processing_settings = {
	"workerCount" => 8,
	"workerMemory" => 1024,
	"workerTemp" => "C:\\WorkerTemp",
}
# Set the parallel processing settings
batch_exporter.setParallelProcessingSettings(parallel_processing_settings)
```

Any settings which you do not explicitly set in your Hash will use Nuix defined defaults.  For a list of settings and their defaults, see the API documentation for [BatchExporter.setParallelProcessingSettings].

**Note**: The `workerCount` setting is independent of how many workers you acquired with your licence at startup.  If you specify a `workerCount` value higher than what is available Nuix will adjust this to how many you actually have available.  If you set it lower, you will only use the number you specified.  If you do not set it at all, the default is based on the number of CPU cores present, not necessarily how many workers are available.  See the API documentation for [BatchExporter.setParallelProcessingSettings](https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ParallelProcessingConfigurable.html#setParallelProcessingSettings-java.util.Map-) for more details.

## Export Numbering

As demonstrated in [Adding Export Products](#adding-export-products), all products support a `naming` setting.  When the `naming` setting is specified as `document_id` or `document_id_with_page`, the exported product will be named based on a document ID.  This document ID can either be generated at the time of export or be based upon an existing [ProductionSet].

### Generate Numbering

You may define the numbering assigned to exported products by calling [BatchExporter.setNumberingOptions].  This is also where you may configure whether the numbering generated at export will be captured in a new [ProductionSet].

```ruby
# Define a numbering scheme like PROD00001337, PROD00001338, PROD00001339, etc...
numbering_options = {
	"createProductionSet" => true,
	"prefix" => "PROD",
	"documentId" => {
		"minWidth" => 8,
		"startAt" => 1337,
	},
}
# Set the export numbering
batch_exporter.setNumberingOptions(numbering_options)
```

For more details about the available settings see the API documentation for [BatchExporter.setNumberingOptions].

### Production Set Based Numbering

You may use the numbering provided by an existing production set.  See [Export a Production Set](#export-a-production-set) and [Export a Subset of a Production Set](#export-a-subset-of-a-production-set) for more details.

## Add Optional Callbacks

An optional step is to add callbacks to the [BatchExporter].  This allows your script to provide code which will be executed by Nuix in response to particular events.

An example of this is the callback [BatchExporter.whenItemEventOccurs].  You define a callback by providing a Ruby code block which will be passed an instance of [ProcessedItem] for each item which is processed.

```ruby
# Add callback for when an item event occurs
batch_exporter.whenItemEventOccurs do |event_info|
	stage = event_info.getStage
	stage_count = event_info.getStageCount
	puts "Stage: #{stage}"
	puts "Stage Count: #{stage_count}"
end
```

[BatchExporter] also provides callbacks [BatchExporter.beforeExport] and [BatchExporter.afterExport].

```ruby
# Add a before export callback
batch_exporter.beforeExport do |info|
	export_item_count = info.getItems.size
	puts "Getting ready to export #{export_item_count} items..."
	next true #Tell Nuix to proceed
end

# Add an after export callback which reports info about failed items
batch_exporter.afterExport do |info|
	export_item_count = info.getItems.size
	failed_items = info.getFailedItems
	puts "Finished exporting #{export_item_count} items"
	if failed_items.size > 0
		puts "#{failed_items.size} items failed"
		failed_items.each do |failed_item|
			puts "\t#{failed_item.getGuid} : #{failed_item.getName}"
		end
	end
end
```

## Beginning Export

Once you have obtained and configured an instance of [BatchExporter], you may begin exporting by calling one of the several `exportItems` methods available.  Script execution will continue beyond the call to `exportItems` once export has completed.

### Export a List of Items

You can export a list of items which may be, for example, the results of a search.

```ruby
# Obtain the items to export
export_items = $current_case.search("tag:ToExport")
# Begin export
puts "Beginning Export..."
batch_exporter.exportItems(export_items)
puts "Export Completed"
```

### Export a Production Set

You can export the items contained in an existing production set.

```ruby
# Define the existing production set name
production_set_name = "My Production Set"
# Obtain the production set
production_set = $current_case.findProductionSetByName(production_set_name)
# Begin export
puts "Beginning Export..."
batch_exporter.exportItems(production_set)
puts "Export Completed"
```

### Export a Subset of a Production Set

You can also provide a production set and list of items from that production set to export just a subset.

```ruby
# Define the existing production set name
production_set_name = "My Production Set"
# Obtain the production set
production_set = $current_case.findProductionSetByName(production_set_name)
# Obtain the production set subset items
export_items = $current_case.search("tag:SubsetToExport")
#Begin export
puts "Beginning Export..."
batch_exporter.exportItems(production_set,export_items)
puts "Export Completed"
```

## Example Export Script

The following is a simple example of an export script based on the previous examples.

```ruby
# Define the export root directory
export_location = "C:\\Exports\\Export123"
# Obtain an exporter
batch_exporter = $utilities.createBatchExporter(export_location)

# Define our traversal settings
traversal_options = {
    "strategy" => "deduplicated_top_level_items_and_descendants",
    "deduplication" => "md5",
    "sortOrder" => "top_level_item_date",
}
# Set the traversal options
batch_exporter.setTraversalOptions(traversal_options)

# Define our native settings Hash
native_settings = {
    "naming" => "guid",
    "path" => "NATIVES",
    "mailFormat" => "msg",
    "includeAttachments" => true,
}
# Add natives to the export
batch_exporter.addProduct("native",native_settings)

# Define our text settings Hash
text_settings = {
    "naming" => "guid",
    "path" => "TEXT",
    "lineSeparator" => "\n",
    "encoding" => "UTF-8",
}
# Add text files to the export
batch_exporter.addProduct("text",text_settings)

# Define our PDF settings Hash
pdf_settings = {
    "naming" => "guid",
    "path" => "PDF",
    "regenerateStored" => true,
}
# Add PDFs to the export
batch_exporter.addProduct("pdf",pdf_settings)

# Define our load file settings Hash
load_file_settings = {
    "metadataProfile" => "Default metadata profile",
    "encoding" => "UTF-8",
}
# Add a concordance DAT load file to the export
batch_exporter.addLoadFile("concordance",load_file_settings)

# Define our settings Hash
parallel_processing_settings = {
    "workerCount" => 8,
    "workerMemory" => 1024,
    "workerTemp" => "C:\\WorkerTemp",
}
# Set the parallel processing settings
batch_exporter.setParallelProcessingSettings(parallel_processing_settings)

# Define a numbering scheme like PROD00001337, PROD00001338, PROD00001339, etc...
numbering_options = {
    "createProductionSet" => true,
    "prefix" => "PROD",
    "documentId" => {
        "minWidth" => 8,
        "startAt" => 1337,
    },
}
# Set the export numbering
batch_exporter.setNumberingOptions(numbering_options)

# Add callback for when an item event occurs
batch_exporter.whenItemEventOccurs do |event_info|
    stage = event_info.getStage
    stage_count = event_info.getStageCount
    puts "Stage: #{stage}"
    puts "Stage Count: #{stage_count}"
end

# Add a before export callback
batch_exporter.beforeExport do |info|
    export_item_count = info.getItems.size
    puts "Getting ready to export #{export_item_count} items..."
    next true #Tell Nuix to proceed
end

# Add an after export callback which reports info about failed items
batch_exporter.afterExport do |info|
    export_item_count = info.getItems.size
    failed_items = info.getFailedItems
    puts "Finished exporting #{export_item_count} items"
    if failed_items.size > 0
        puts "#{failed_items.size} items failed:"
        failed_items.each do |failed_item|
            puts "\t#{failed_item.getGuid} : #{failed_item.getName}"
        end
    end
end

# Obtain the items to export
export_items = $current_case.search("tag:ToExport")
# Begin export
puts "Beginning Export..."
batch_exporter.exportItems(export_items)
puts "Export Completed"
```

# Single Item Exporters

Nuix provides several [SingleItemExporter] objects.  These objects are each able to export a certain type of product one item at a time.

The benefit to this approach is that this allows absolute control over the filename and path a given file is exported to.  This can be useful in supporting complex export structures.

The downsides are that using using them may not perform as well as using a [BatchExporter] and this approach does not have a way to generate a load file.

## Basic Usage

You obtain a particular type of [SingleItemExporter] by calling the appropriate method of the [Utilities] object outlined below.  This will return an instance of [SingleItemExporter] configured for a specific type of export product.  The settings accepted by a given [SingleItemExporter] when calling its `exportItem` method, are documented in the [Utilities] method which provides it.

The following is an example of using the text exporter.

```ruby
# Define the directory to export text files to
export_directory = "C:\\Exports\\ExampleTextExport"
# Make sure directory exists
java.io.File.new(export_directory).mkdirs
# Available text settings are documented in Utilities.getTextExporter
exporter_settings = {
	"lineSeparator" => "\n",
	"charset" => "UTF-8",
}
text_exporter = $utilities.getTextExporter
items = $current_case.search("tag:ItemsToExport")
items.each_with_index do |item,item_index|
	# Export each item with an 8 fill sequential number, starting at 00000000
	padded_number_string = item_index.to_s.rjust(8,"0")
	# Determine the text files name
	text_file_name = "#{padded_number_string}.txt"
	# Determine the full path by joining export_directory and text_file_name
	export_file_path = File.join(export_directory,text_file_name)
	# Export the text file for this item
	text_exporter.exportItem(item,export_file_path,exporter_settings)
end
```
## Single Item Exporter Variations

### Binary Exporter

You can obtain an instance of a [SingleItemExporter] configured for exporting binaries of items by calling [Utilities.getBinaryExporter].  This type of exporter supports no additional settings.

### Email Exporter

You can obtain an instance of a [SingleItemExporter] configured for exporting emails of items by calling [Utilities.getEmailExporter].  Use this to export emails into formats such as:

* eml
* msg
* dxl

### Mailbox Exporter

You can obtain an instance of a [SingleItemExporter] configured for exporting emails of items into a mail store by calling [Utilities.getEmailExporter].  Use this to export emails into formats such as:

* mbox
* pst
* nsf

### PDF Exporter

You can obtain an instance of a [SingleItemExporter] configured for exporting PDFs of items by calling [Utilities.getPdfPrintExporter].

### Text Exporter

You can obtain an instance of a [SingleItemExporter] configured for exporting the text files of items by calling [Utilities.getTextExporter].

### Thumbnail Exporter

You can obtain an instance of a [SingleItemExporter] configured for exporting the thumbnail images of items by calling [Utilities.getThumbnailExporter].

### TIFF Exporter

You can obtain an instance of a [SingleItemExporter] configured for exporting the TIFF images of items by calling [Utilities.getTiffPrintExporter].

[BatchExporter]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/BatchExporter.html
[BatchExporter.addProduct]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/BatchExporter.html#addProduct-java.lang.String-java.util.Map-
[BatchExporter.addLoadFile]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/BatchExporter.html#addLoadFile-java.lang.String-java.util.Map-
[BatchExport.setTraversalOptions]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/BatchExporter.html#setTraversalOptions-java.util.Map-
[BatchExporter.setParallelProcessingSettings]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ParallelProcessingConfigurable.html#setParallelProcessingSettings-java.util.Map-
[BatchExporter.setNumberingOptions]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/NumberingConfigurable.html#setNumberingOptions-java.util.Map-
[BatchExporter.whenItemEventOccurs]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/BatchExporter.html#whenItemEventOccurs-nuix.ItemEventCallback-
[BatchExporter.beforeExport]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/BatchExporter.html#beforeExport-nuix.BeforeExportCallback-
[BatchExporter.afterExport]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/BatchExporter.html#afterExport-nuix.AfterExportCallback-
[Utilities]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Utilities.html
[Utilities.createBatchExporter]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Utilities.html#createBatchExporter-java.lang.String-
[SingleItemExporter]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/SingleItemExporter.html
[Utilities.getBinaryExporter]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Utilities.html#getBinaryExporter--
[Utilities.getEmailExporter]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Utilities.html#getEmailExporter--
[Utilities.getMailboxExporter]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Utilities.html#getMailboxExporter--
[Utilities.getPdfPrintExporter]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Utilities.html#getPdfPrintExporter--
[Utilities.getTextExporter]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Utilities.html#getTextExporter--
[Utilities.getThumbnailExporter]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Utilities.html#getThumbnailExporter--
[Utilities.getTiffPrintExporter]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Utilities.html#getTiffPrintExporter--
[ProductionSet]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ProductionSet.html