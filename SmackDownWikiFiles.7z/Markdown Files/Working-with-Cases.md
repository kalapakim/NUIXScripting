- [Current Case](#current-case)
- [Opening an Existing Case](#opening-an-existing-case)
  - [Allowing Case Migration](#allowing-case-migration)
- [Creating a Case](#creating-a-case)
- [Closing a Case](#closing-a-case)
- [Case Contents](#case-contents)
  - [Get All Custodians](#get-all-custodians)
  - [Get All Tags](#get-all-tags)
  - [Get All Types](#get-all-types)
  - [Get All Evidence Containers](#get-all-evidence-containers)
  - [Get All Metadata Items](#get-all-metadata-items)

# Current Case

If you are running your script via the [scripts menu](RunningYourScript.html#using-the-scripts-menu) or [script console](RunningYourScript.html#using-the-script-console) you can access a case which is already open in the GUI.  If a case is already open in the GUI, Nuix will populate the global variable `$current_case`.

If there was not a case open in the GUI when the script is started or you are running the script using [Nuix Console](RunningYourScript.html#using-nuix-console) `$current_case` will be `nil`.

```ruby
if $current_case.nil?
	puts "No case is open"
else
	puts "Case is already open"
end
```

# Opening an Existing Case

To open a case for script to work with, we need to use the [CaseFactory](https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/CaseFactory.html) which provides the method [open](https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/CaseFactory.html#open-java.lang.String-).

```ruby
# Define the case directory
case_directory = "C:\\Cases\\Case123"
# Obtain the case factory
case_factory = $utilities.getCaseFactory
# Open the case and store a reference to it in the variable 'nuix_case'
nuix_case = case_factory.open(case_directory)
```
## Allowing Case Migration

If the case being opened requires migration, because the version of Nuix being used is higher than that of the case, the previous example will cause an error.  This is because by default this call does not give Nuix permission to migrate a case to a newer version.

To allow case migration, we need to use an overload of [CaseFactory.open](https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/CaseFactory.html#open-java.lang.String-java.util.Map-) which takes a second argument which we can use to give Nuix permission to migrate the case if needed.

```ruby
# Define the case directory
case_directory = "C:\\Cases\\Case123"
# Obtain the case factory
case_factory = $utilities.getCaseFactory
# Open the case and give permission to migrate as needed
nuix_case = case_factory.open(case_directory,{ "migrate" => true })
```

# Creating a Case

Case creation is performed by calling the [CaseFactory.create](https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/CaseFactory.html#create-java.lang.String-java.util.Map-) method.  You provide the method the location to create the case and some additional case settings in a [Ruby Hash].

```ruby
# Define the case directory
case_directory = "C:\\Cases\\Case123"
# Define the settings used while creating the case
case_settings = {
	"compound" => false,
	"name" => "Case 123",
	"description" => "This is case 123",
	"investigator" => "Jason Wells",
}
# Obtain the case factory
case_factory = $utilities.getCaseFactory
# Create the case
nuix_case = case_factory.create(case_directory,case_settings)
```

# Closing a Case

When you are finished using a case opened by your script, you should make sure to close it using [Case.close](https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Case.html#close--).

```ruby
# Define the case directory
case_directory = "C:\\Cases\\Case123"
# Obtain the case factory
case_factory = $utilities.getCaseFactory
# Open the case
nuix_case = case_factory.open(case_directory,{ "migrate" => true })

# Use the case here
hits = $current_case.search("term")

# Close the case when we are done with it
$current_case.close
```

**Note**: A case which was opened by the user in the GUI and obtained via the global variable `$current_case` cannot be closed by a script!  The GUI is responsible for closing such a case.  An attempt to close a case opened by the user in the GUI from a script will result in an exception.

# Case Contents

The [Case] object provides various methods for obtaining an idea of what is present in a case.

## Get All Custodians

You can get a list of all the custodian names present in the case using [Case.getAllCustodians].  The following is an example which reports the count of items for each custodian.

```ruby
# Get an array of all the custodians in the current case
all_custodians = $current_case.getAllCustodians
# Iterate each custodian name
all_custodians.sort.each do |custodian_name|
	# Query the count of items which have this custodian assigned
	custodian_item_count = $current_case.count("custodian:\"#{custodian_name}\"")
	# Report the count
	puts "\t#{custodian_name}: #{custodian_item_count}"
end
```

**Example Output**

```
James Smith: 4101
Kenneth Smith: 20737
Rick Smith: 18931
```

## Get All Tags

You can get a list of all the tags present in a case using [Case.getAllTags].  The following is an example which reports the count of items for each tag.

```ruby
# Get an array of all the tags in the current case
all_tags = $current_case.getAllTags
# Iterate each tag
all_tags.sort.each do |tag|
	# Query the count of items with this tag
	tag_item_count = $current_case.count("tag:\"#{tag}\"")
	# Report the count
	puts "#{tag}: #{tag_item_count}"
end
```

**Example Output**

```
Animals: 0
Animals|Ant: 3
Animals|Bat: 9
Animals|Camel: 3
Animals|Deer: 2
Animals|Eagle: 46
Animals|Falcon: 123
Animals|Gorilla: 8
```

## Get All Types

Nuix classifies items by their [ItemType].  Each [ItemType] has an associated [ItemKind] and mime-type.  You can get a listing of all [ItemTypes][ItemType] present in a case using [Case.getItemTypes].  The following example reports each [ItemType] present in a case along with it's associated [ItemType], type name, mime-type and number of items with the associated [ItemType].

```ruby
# Get an array of all the ItemTypes present in the current case
all_present_types = $current_case.getItemTypes
# Sort them by kind then by their 'user friendly' name
all_present_types = all_present_types.sort_by{|item_type| [item_type.getKind.getName,item_type.getLocalisedName] }
# Iterate the now sorted item types
all_present_types.each do |item_type|
	# Get the kind name of this type
	item_kind_name = item_type.getKind.getName
	# Get the localised name (user friendly name) of this type
	item_type_name = item_type.getLocalisedName
	# Get the type name (often referred to as the 'mime-type')
	mime_type = item_type.getName
	# Get the count of items which are of this type
	item_type_count = $current_case.count("mime-type:\"#{mime_type}\"")
	# Report the count
	puts "#{item_kind_name} : #{item_type_name} : #{mime_type} : #{item_type_count}"
end
```

**Example Output**

```
contact : vCard Contact : text/vcard-contact : 23
container : MacBinary Archive : application/macbinary : 2
container : Microsoft ClipArt Gallery : application/vnd.ms-clipart-gallery : 90
container : Microsoft Marshaled Server Object : application/vnd.ms-mso : 20
container : Microsoft OLE2 Attachment Wrapper : application/vnd.ms-ole2-attachment : 6
container : Microsoft OLE2 Clipboard Wrapper : application/vnd.ms-ole2-clipboard : 14
container : Microsoft OLE2 Package File : application/vnd.ms-ole2-package : 443
container : Microsoft Outlook Folder : application/vnd.ms-outlook-folder : 108
container : Microsoft Outlook Personal Folder : application/vnd.ms-outlook : 4
container : Microsoft Photo Editor Object : application/vnd.ms-photo-editor : 133
container : Microsoft Transport Neutral Encapsulation Format File : application/vnd.ms-tnef : 26
container : Nuix Evidence File : application/vnd.nuix-evidence : 4
container : ZLIB Compressed Stream : application/x-zlib-stream : 14
container : Zip-Compressed File : application/x-zip-compressed : 12
container : gzip-Compressed File : application/x-gzip : 24
container : vCard File : text/vcard : 23
document : Hypertext Markup Language Document : text/html : 123
document : Microsoft Word Document : application/vnd.ms-word : 4141
document : Microsoft Word Pre-OLE2 Document : application/vnd.ms-word-pre-ole2 : 8
document : Portable Document Format : application/pdf : 339
document : Rich Text Format : text/rtf : 36
document : WordPerfect Document : application/vnd.corel-wordperfect : 36
drawing : Corel Draw 6.0 Graphic : image/vnd.corel-draw-6 : 30
drawing : Corel Draw Drawing : image/vnd.corel-draw : 24
drawing : HumanConcepts OrgPlus Document : application/vnd.humanconcepts-orgplus : 23
drawing : Microsoft Excel Chart : application/vnd.ms-excel-chart : 32
drawing : Microsoft Graph Chart : application/vnd.ms-graph : 571
drawing : Microsoft Visio Drawing : application/vnd.ms-visio : 12
drawing : Microsoft Windows Enhanced Metafile : image/vnd.ms-emf : 1209
drawing : Microsoft Windows Metafile : image/vnd.ms-wmf : 1384
drawing : Microsoft Word Picture : application/vnd.ms-word-picture : 278
email : Microsoft Outlook Note : application/vnd.ms-outlook-note : 48686
email : RFC822 Email Message : message/rfc822 : 2
image : Adobe Photoshop Image : application/vnd.adobe-photoshop : 56
image : Compuserve Graphic Interchange Format : image/gif : 77
image : JPEG/JFIF Image : image/jpeg : 1080
image : Lotus Freelance Graphics : image/vnd.lotus-freelance : 4
image : PCX Image : image/pcx : 18
image : Portable Network Graphic : image/png : 1992
image : Tagged Image Format File : image/tiff : 38
image : Windows Bitmap Graphic : image/bmp : 281
multimedia : MPEG Audio File : audio/mpeg : 4
multimedia : Microsoft Advanced Systems Format (ASF) Multimedia File : video/vnd.ms-asf : 2
no-data : Empty File : application/x-empty : 13
no-data : Inaccessible Content : filesystem/inaccessible : 28
other-document : Ini Style Configuration File : text/x-ini : 1114
other-document : Microsoft Equation Object : application/vnd.ms-equation : 12
other-document : Microsoft Office VBA File : application/vnd.ms-office-vba : 1
other-document : Microsoft Project File : application/vnd.ms-project : 1
presentation : Microsoft PowerPoint Presentation : application/vnd.ms-powerpoint : 281
spreadsheet : Microsoft Excel Spreadsheet : application/vnd.ms-excel : 1152
system : Microsoft OLE2 Standard Link : application/vnd.ms-ole2-std-link : 9
system : Microsoft Outlook Property Block : application/vnd.ms-outlook-property-block : 9
unrecognised : Microsoft OLE2 File : application/vnd.ms-ole2 : 4
unrecognised : Plain Text : text/plain : 369
unrecognised : Unknown Binary File : application/octet-stream : 75
```

## Get All Evidence Containers

You can get all the evidence container items present in a case using [Case.getRootItems].  The following example script reports each evidence container's name and the count of items beneath it.

```ruby
# Get all evidence container items in the current case
evidence_container_items = $current_case.getRootItems
# Iterate each evidence container item
evidence_container_items.each do |evidence_item|
	# Get the name of the evidence container item
	evidence_item_name = evidence_item.getName
	# Get the GUID of the evidence container item
	evidence_item_guid = evidence_item.getGuid
	# Query for the count of items which are descendants of this evidence container item
	# using a query for 'path-guid' specifying the GUID of the evidence container item
	evidence_descendant_count = $current_case.count("path-guid:\"#{evidence_item_guid}\"")
	# Report the count
	puts "#{evidence_item_name}: #{evidence_descendant_count}"
end
```

**Example Output**

```
Data1: 4100
Data2: 20736
Data3: 18930
```

## Get All Metadata Items

You can get all the [MetadataItems][MetadataItem] in a case using [Case.getMetadataItems].  A [MetadataItem] object represents a field which can be present in a [MetadataProfile].  The following example script reports the name of all the [MetadataItems][MetadataItem] present in a case, sorted by name.

```ruby
# Get all the metadata items in the current case
all_metadata_items = $current_case.getMetadataItems
# Sort by name
all_metadata_items = all_metadata_items.sort_by{|metadata_item| metadata_item.getName}
# Iterate each metadata item and print its name
all_metadata_items.each do |metadata_item|
	puts metadata_item.getName
end
```

**Example Output**

```
% Complete
% Work Complete
Abstract
Addressee(s)
Adobe Jpeg: Color Transform
Adobe Jpeg: DCT Encode Version
Adobe Jpeg: Flags 0
Adobe Jpeg: Flags 1
AlreadySaved
AppName
Apple File Creator
Apple File Flags
Apple File Type
Application Created
Application Modified
Application Version
Audited
Audited Size
Author
AuthorID
AuthorName
AutomaticClassifications
AutomaticClassifierConfidence
AutomaticClassifierGainConfidence
BackColor
Batch Load GUID
... ETC ...
```

[Case]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Case.html
[Case.getAllCustodians]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Case.html#getAllCustodians--
[Case.getAllTags]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Case.html#getAllTags--
[ItemType]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemType.html
[Case.getItemTypes]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Case.html#getItemTypes--
[ItemKind]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemKind.html
[Case.getRootItems]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Case.html#getRootItems--
[MetadataItem]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/MetadataItem.html
[Case.getMetadataItems]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Case.html#getMetadataItems--
[MetadataProfile]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/MetadataProfile.html
[Ruby Hash]: RubyBasics.html#hash