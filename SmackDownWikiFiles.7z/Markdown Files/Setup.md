Using the Nuix Scripting API requires the Nuix Workstation software and a valid Nuix license.

That may be a licence dongle issued by Nuix:
![Via USB dongle](nuix-dongle.png)

Or a licence which is obtained across the network from a system running [Nuix Management Server] which hosts and distributes licences.
![Via Nuix Management Server (NMS)](nuix-server.png)

[Nuix Management Server]: https://download.nuix.com/releases/server