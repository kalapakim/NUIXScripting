﻿- [Custodian](#custodian)
  - [Get all Custodians](#get-all-custodians)
  - [Get an Item's Custodian](#get-an-items-custodian)
  - [Assign a Custodian to an Item](#assign-a-custodian-to-an-item)
  - [Assign a Custodian to Multiple Items](#assign-a-custodian-to-multiple-items)
- [Tags](#tags)
  - [Get all Tags](#get-all-tags)
  - [Get an Item's Tags](#get-an-items-tags)
  - [Assigning Tags to an Item](#assigning-tags-to-an-item)
  - [Tagging Multiple Items](#tagging-multiple-items)
- [Custom Metadata](#custom-metadata)
  - [Get an Item's Custom Metadata](#get-an-items-custom-metadata)
  - [Apply Custom Metadata to an Item](#apply-custom-metadata-to-an-item)
  - [Apply Custom Metadata to Multiple Items](#apply-custom-metadata-to-multiple-items)
- [Comments](#comments)
  - [Get an Item's Comment](#get-an-items-comment)
  - [Set an Item's Comment](#set-an-items-comment)
  - [Append to Existing Comment](#append-to-existing-comment)
- [Exclusions](#exclusions)
  - [Get Whether an Item is Excluded](#get-whether-an-item-is-excluded)
  - [Set Whether an Item is Excluded](#set-whether-an-item-is-excluded)
  - [Exclude Multiple Items](#exclude-multiple-items)
  - [Set Whether an Item is Included](#set-whether-an-item-is-included)
  - [Include Multiple Items](#include-multiple-items)

# Custodian

## Get all Custodians

A listing of all custodians in the case can be obtained from the [Case] object, see [[Working with Cases]].

## Get an Item's Custodian

Items may have a custodian name assigned to them.  To determine the custodian name currently assigned to an item use [Item.getCustodian].  Note that if an item has no custodian assigned, [Item.getCustodian] will return `nil`.

```ruby
items = $current_case.search("")
items.each do |item|
	custodian_name = item.getCustodian
	if custodian_name.nil?
		puts "Item #{item.getName} has no custodian assigned"
	else
		puts "Item #{item.getName} belongs to custodian #{item.getCustodian}"
	end
end
```

## Assign a Custodian to an Item

You can assign a custodian name to an item using [Item.assignCustodian].

```ruby
custodian_name = "Bob Smith"
items = $current_case.search("bob")
items.each do |item|
	item.assignCustodian(custodian_name)
end
```

## Assign a Custodian to Multiple Items

If you are going to apply a custodian name to multiple items at once, you may instead use the [BulkAnnotater] method [BulkAnnotater.assignCustodian].

```ruby
custodian_name = "Bob Smith"
items = $current_case.search("bob")
annotater = $utilities.getBulkAnnotater
annotater.assignCustodian(custodian_name,items)
```

# Tags

## Get all Tags

A listing of all tags in the case can be obtained from the [Case] object, see [[Working with Cases]].

## Get an Item's Tags

You can determine the tags present on an item by calling [Item.getTags]:

```ruby
items = $current_case.search("")
items.each do |item|
	tags = item.getTags
	puts "Item Tags:"
	tags.each do |tag|
		puts tag
	end
end
```

## Assigning Tags to an Item

The simplest way to add a tag to an item is by calling the [Item.addTag] method.

```ruby
tag = "RelevantItems"
items = $current_case.search("")
items.each do |item|
	item.addTag(tag)
end
```
## Tagging Multiple Items

The [Item.addTag] method is convenient for a few items, but if you are applying a tag to multiple items you will see better performance by using the [BulkAnnotater.addTag] method:

```ruby
tag = "RelevantItems"
items = $current_case.search("")
annotater = $utilities.getBulkAnnotater
annotater.addTag(tag, items)
```

# Custom Metadata

Custom metadata allows you to annotate items with a named field of data. Custom metadata supports several data types:

* Integers
* Long Integers
* Floating Point Numbers
* Double Precision Floating Point Numbers
* DateTime
* Text
* Booleans
* Binary

See the documentation for [ItemCustomMetadataMap.put](https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemCustomMetadataMap.html#put-java.lang.String-java.lang.Object-java.lang.String-java.lang.String-java.util.Map-) for more details.

## Get an Item's Custom Metadata

You can get the custom metadata present on an item by calling the [Item.getCustomMetadata].  This method will return a [CustomMetadataMap] which from the perspective of your Ruby script is a Ruby Hash.

You access the value of a given custom metadata field as you would access the value in a Hash, providing the custom metadata field name as the key.

```ruby
items = $current_case.search("")
items.each do |item|
	item_custom_metadata = item.getCustomMetadata
	custom_int = item_custom_metadata["Custom Int"]
	puts "Custom Int: #{custom_int}"
end
```

**Important**: If an item does not have a value for a given field name, the value returned will be `nil`.

If you want to test whether a custom metadata field is present (regardless of whether it has a value or not) you can use the Ruby Hash method [has_key?](http://ruby-doc.org/core-1.9.3/Hash.html#method-i-has_key-3F).

```ruby
items = $current_case.search("")
items.each do |item|
	item_custom_metadata = item.getCustomMetadata
	has_my_field = item_custom_metadata.has_key?("My Field")
	puts "Item has 'My Field': #{has_my_field}"
end
```

## Apply Custom Metadata to an Item

To apply or modify custom metadata on an item you can modify values of the [CustomMetadataMap]:

```ruby
items = $current_case.search("")
items.each do |item|
	item_custom_metadata = item.getCustomMetadata
	item_custom_metadata["Custom Int"] = 123
end
```

## Apply Custom Metadata to Multiple Items

If you are going to be applying custom metadata to multiple items it is recommended you do this in bulk using the [BulkAnnotater.putCustomMetadata] method for improved performance:

```ruby
field_name = "Custom Text"
field_value = "ABC 123"
items = $current_case.search("")
annotater = $utilities.getBulkAnnotater
annotater.putCustomMetadata(field_name, field_value, items, nil)
```

You may have noticed in the previous example that the last argument passed to `putCustomMetadata` was `nil`.  This is because `putCustomMetadata` accepts an optional callback which will be called once for each item the custom metadata is applied to.  In the previous example `nil` was provided to opt out of providing a callback.

Providing this callback would look something like this:

```ruby
field_name = "Custom Text"
field_value = "ABC 123"
items = $current_case.search("")
annotater = $utilities.getBulkAnnotater
annotater.putCustomMetadata(field_name, field_value, items) do |event_info|
	# Do something here in the callback
end
```

# Comments

## Get an Item's Comment

You can get the comment currently present on an item by calling the [Item.getComment] method:

```ruby
items = $current_case.search("")
items.each do |item|
	item_comment = item.getComment
	puts "Item Comment: #{item_comment}"
end
```

## Set an Item's Comment

You can similarly set the comment of an item using the [Item.setComment] method:

```ruby
query = "cat AND dog"
items = $current_case.search(query)
items.each do |item|
	item.setComment("This item hit on query: #{query}")
end
```

The [Item.setComment] method will overwrite any comment which may already be present.

## Append to Existing Comment

If you wish to instead add to the existing comment you may use the [Item.appendComment] method:

```ruby
query = "cat AND dog"
items = $current_case.search(query)
items.each do |item|
	item.appendComment("This item hit on query: #{query}")
end

items.each do |item|
	item.appendComment("Appending another comment")
end
```

# Exclusions

Exclusions afford you a way to hide items which you may have deemed as irrelevant.

**Important:** Searches submit through the API are not subject to some of the additional manipulations which would be performed were you to run the same search through the GUI.  Searches submit through the API do **NOT** automatically have excluded items removed and do **NOT** apply the default fields specified in the GUI *Global Options* (unless you call the appropriate method).  If you wish for similar behavior when searching through the API you must modify your query to contain similar logic or manipulate the resulting item collection afterwards.  See [[Searching]] for more details.

## Get Whether an Item is Excluded

You can test whether a given item is excluded by calling the [Item.isExcluded] method:

```ruby
query = "family w/1 photos"
items = $current_case.search(query)
items.each do |item|
	is_excluded = item.isExcluded
	puts "Item is Excluded: #{is_excluded}"
end
```

## Set Whether an Item is Excluded

Items can be excluded individually using the [Item.exclude] method:

```ruby
query = "family w/1 photos"
reason = "Family Photos"
items = $current_case.search(query)
items.each do |item|
	item.exclude(reason)
end
```
## Exclude Multiple Items

If you are going to exclude multiple items at once you are better off using the [BulkAnnotater.exclude] method:

```ruby
query = "family w/1 photos"
reason = "Family Photos"
items = $current_case.search(query)
annotater = $utilities.getBulkAnnotater
annotater.exclude(reason, items)
```

## Set Whether an Item is Included

Removing exclusions from items (AKA "including" them) is similarly done using [Item.include] for items individually:

```ruby
query = "family w/1 photos"
items = $current_case.search(query)
items.each do |item|
	item.include
end
```

## Include Multiple Items

Multiple items can be included in bulk by using calling the [BulkAnnotater.include] method:

```ruby
query = "family w/1 photos"
items = $current_case.search(query)
annotater = $utilities.getBulkAnnotater
annotater.include(items)
```

[Item.addTag]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Item.html#addTag-java.lang.String-
[Item.appendComment]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Item.html#appendComment-java.lang.String-
[Item.exclude]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Item.html#exclude-java.lang.String-
[Item.getComment]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Item.html#getComment--
[Item.getCustomMetadata]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Item.html#getCustomMetadata--
[Item.getTags]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Item.html#getTags--
[Item.include]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Item.html#include--
[Item.isExcluded]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Item.html#isExcluded--
[Item.setComment]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Item.html#setComment-java.lang.String-
[Case.createItemSet]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Case.html#createItemSet-java.lang.String-java.util.Map-
[Case.findItemSetByName]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Case.html#findItemSetByName-java.lang.String-
[Case.getAllItemSets]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Case.html#getAllItemSets--
[ItemSet]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemSet.html
[ItemSet.addItems]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemSet.html#addItems-java.util.Collection-java.util.Map-
[BulkAnnotater.addTag]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/BulkAnnotater.html#addTag-java.lang.String-java.util.Collection-
[BulkAnnotater.exclude]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/BulkAnnotater.html#exclude-java.lang.String-java.util.Collection-
[BulkAnnotater.include]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/BulkAnnotater.html#include-java.util.Collection-
[BulkAnnotater.putCustomMetadata]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/BulkAnnotater.html#putCustomMetadata-java.lang.String-java.lang.Object-java.util.Collection-nuix.ItemEventCallback-
[CustomMetadataMap]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/CustomMetadataMap.html
[Item.getCustodian]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Item.html#getCustodian--
[Case]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Case.html
[BulkAnnotater]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/BulkAnnotater.html
[BulkAnnotater.assignCustodian]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/BulkAnnotater.html#assignCustodian-java.lang.String-java.util.Collection-
[Item.assignCustodian]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Item.html#assignCustodian-java.lang.String-
[Case]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Case.html