- [Overview](#overview)
- [Comments](#comments)
- [Basic Data Types](#basic-data-types)
  - [Nil](#nil)
  - [Boolean](#boolean)
  - [String](#string)
  - [Numeric](#numeric)
  - [Array](#array)
  - [Hash](#hash)
- [Output](#output)
- [Conditional Tests](#conditional-tests)
  - [If](#if)
  - [Else](#else)
  - [Else If](#else-if)
  - [Boolean Logic](#boolean-logic)
    - [AND](#and)
    - [OR](#or)
    - [Complex Boolean Logic](#complex-boolean-logic)
    - [Logic Short Circuiting](#logic-short-circuiting)
  - [Case/When/Else](#case/when/else)
- [Methods](#methods)
- [Scripting Tricks](#scripting-tricks)
  - [Current Script File Path](#current-script-file-path)
  - [Current Method Name](#current-method-name)
  - [Java System Properties](#java-system-properties)

# Overview

This serves as a quick crash course or refresher for Ruby.  By no means is this an exhaustive resource.  For further information about the Ruby language I recommend reading one of the many Ruby tutorials available on the internet.

# Comments

Ruby allows you to place comments within your code.  Comments are ignored by Ruby, allowing a way for you to document your code.  A comment in Ruby is `#` followed by your comment.

```ruby
# This is a comment
sum = 1 + 2 # This is also a comment
```

In addition to normal comments Nuix recognizes several special comments which can be placed at the beginning of the script.  See [[here|Running your Script]] for more details.

# Basic Data Types

## Nil

In Ruby, `nil` (sometimes called [null](https://en.wikipedia.org/wiki/Null_pointer) in other languages) represents a value of nothing.  You can check whether a variable is `nil` using the Ruby method [nil?].

```ruby
value_a = 42
value_b = nil

puts "Value A is nil:"
puts value_a.nil?

puts "Value B is nil:"
puts value_b.nil?
```

```
Value A is nil:
false
Value B is nil:
true
```

**Important:** Checking for `nil` values can help in preventing `NullReferenceException` errors, which can occur when making an API call which expects a value of some sort, but your code accidentally provides a `nil` value instead.  If you think a variable may `nil`, it is often worth making a quick check for `nil` to make your code more stable!

## Boolean

Boolean values are either `true` or `false`.

```ruby
tag_emails = true
export_emails = false

if tag_emails == true
	# Logic to tag emails here
end

# This also works
if tag_emails
	# Logic to tag emails here
end
```

## String

A string is text data.

```ruby
name = "Jason Wells"
another_name = 'Bob Smith'
```

When double quotes are used, the string supports several escape sequences.

* `\t` for tab
* `\n` for newline
* `\r` for carriage return
* `\\` for backslash

Ruby also supports [string interpolation](https://en.wikipedia.org/wiki/String_interpolation#Ruby) in double quoted strings.  String interpolation allows "injecting" values into the middle of a string.

```ruby
name = "Jason Wells"
puts "Hello #{name}"
puts "The number is #{40 + 2}"
```

```
Hello Jason Wells
The number is 42
```

Ruby also supports multiline string literals.  A multiline string literal begins with `<<IDENTIFIER` and ends with `IDENTIFIER`, `IDENTIFIER` being a value of your choice.  Multiline string literals also support string interpolation.

```ruby
item = $current_case.search("flag:audited").first
item_info = <<ITEMINFO
Name: #{item.getName}
GUID: #{item.getGuid}
ITEMINFO

puts item_info
```

```
Name: FW: Meeting Notes
GUID: 2054dff5-3001-4ab8-8c04-e493ed3b2bc6
```

## Numeric

Ruby supports integers ([Fixnum],[Bignum]) and floating point numbers ([Float]).

```ruby
integer_value = 12345
float_value = 3.14159
```

## Array

A Ruby [Array] is a collection of multiple values stored together.

```ruby
empty_array = []

number_array = [1,2,3]

name_array = [
	"Jason",
	"Bob",
	"Ron",
]
```

You can append values to the end of an [Array] using the `<<` operator.

```ruby
# Create array with single element: 100
numbers = [100]
puts "A: #{numbers.inspect}"

# Append 42
numbers << 42
puts "B: #{numbers.inspect}"

# Append 1337
numbers << 1337
puts "C: #{numbers.inspect}"
```

```
A: [100]
B: [100, 42]
C: [100, 42, 1337]
```

You can concatenate two arrays using the `+` operator.

```ruby
# Define two arrays
array_a = [1,3,5,7]
array_b = [2,4,6,8]
# Show their contents
puts "array_a: #{array_a.inspect}"
puts "array_b: #{array_b.inspect}"
# Create a new array containing the other arrays concatenated
both_arrays = array_a + array_b
# Show the newly created concatenated array
puts "both_arrays: #{both_arrays.inspect}"
```

```
array_a: [1, 3, 5, 7]
array_b: [2, 4, 6, 8]
both_arrays: [1, 3, 5, 7, 2, 4, 6, 8]
```

**Note:** that concatenating arrays builds a new array containing the elements of the two source arrays.  Changes made to the source arrays (such as adding and removing elements) will not be reflected in the concatenated array.

You can determine how many elements are present in an array using `size`.

```ruby
colors = ["Red","Blue","Green"]
puts colors.size
```

```
3
```

A Ruby Array can contain a mix of data types, but generally it is a good idea to keep all elements of the Array as a single data type (all strings, all integers, etc).

Array elements can be individually accessed using a sequential index, starting from 0.

```ruby
even_numbers = [2,4,6,8,10]

# First element
puts even_numbers[0]

# Third element
puts even_numbers[2]
```

```
2
6
```

You can iterate each element present in the array using `each`.

```ruby
even_numbers = [2,4,6,8,10]

# Iterate 'each' element as a variable named 'number'
even_numbers.each do |number|
	puts number
end
```

```
2
4
6
8
10
```

Sometimes it is helpful to not only iterate the elements but also the 0 based index of the elements.  This can be done by using [each_with_index](http://ruby-doc.org/core-1.9.3/Enumerator.html#method-i-each_with_index).

```ruby
animals = [
	"cat",
	"dog",
	"mouse",
	"bird",
]

animals.each_with_index do |animal,index|
	puts "#{index} = #{animal}"
end
```

```
0 = cat
1 = dog
2 = mouse
3 = bird
```

## Hash

A Ruby [Hash](http://ruby-doc.org/core-1.9.3/Hash.html) is similar to a Ruby Array, except each value is associated with a key rather than a sequential index.

```ruby
empty_hash = {}

ages = {}
ages["Jason"] = 33
ages["Bob"] = 42

data = {
	"name" => "Jason Wells",
	"age" => 33,
	"programmer" => true,
}
```

Individual values are retrieved similar to an array, but rather than using an index value, you use the associated key.  If you attempt to retrieve a key which is not present in the Hash, you will instead retrieve [nil].

```ruby
ages = {}
ages["Jason"] = 33
ages["Bob"] = 42

puts ages["Jason"]
puts ages["Gorgon"]
```

```
33
nil
```

Also similar to arrays, you can iterate each value present in the Hash.

```ruby
data = {
	"name" => "Jason Wells",
	"age" => 33,
	"programmer" => true,
}

data.each do |key,value|
	puts "#{key} : #{value}"
end
```

```
name : Jason Wells
age : 33
programmer : true
```

You can override the default behavior of returning [nil] for missing keys by using a special Hash constructor method which accepts a Ruby block that defines what the default value should be for a missing key.

For example the following scripts would generate errors.

```ruby
counts_by_kind = {}
items = $current_case.search("kind:email")
items.each do |item|
	# This will have an an error because there is no key "email"
	# therefore the value of "email" is nil, and you cannot
	# add 1 to nil
	counts_by_kind["email"] += 1
end
```

```
NoMethodError: undefined method `+' for nil:NilClass
```

```ruby
names_by_kind = {}
items = $current_case.search("kind:email")
items.each do |item|
	# This will have an an error because there is no key "email"
	# therefore the value of "email" is nil, and you cannot
	# add append an element to nil
	names_by_kind["email"] << item.getName
end
```

```
(NoMethodError) undefined method `<<' for nil:NilClass
```


Creating a Hash using the following method, you are able to define code which determines what the default value for a missing key will be.

```ruby
counts_by_kind = Hash.new{|hash,key| hash[key] = 0}
counts_by_kind["email"] += 1
```

```ruby
names_by_kind = Hash.new{|hash,key| hash[key] = [] }
items = $current_case.search("kind:email")
items.each do |item|
	names_by_kind["email"] << item.getName
end
```

This is especially useful when you do not know what the keys in the Hash will be until runtime.

```ruby
tag_counts = Hash.new{|hash,key| hash[key] = 0}
tagged_items = $current_case.search("has-tag:1")
tagged_items.each do |item|
	item_tags = item.getTags
	item_tags.each do |tag|
		tag_counts[tag] += 1
	end
end
```

# Output

In Ruby you write output to standard out using `puts`.

```ruby
puts "Hello World"
puts "Hello" + " " + "World"
puts 42
puts 100 + 200
```

```
Hello World
Hello World
42
300
```

Depending on how the script is run changes where the output goes.  If your script is ran through the GUI either through the [scripts menu](RunningYourScript.html#using-the-scripts-menu) or the [script console dialog](RunningYourScript.html#using-the-script-console), output is redirected to the output text area of the script console dialog.  If your script is being ran using [nuix_console.exe](RunningYourScript.html#using-nuix-console), then output will be direted to standard out of the console session which invoked [nuix_console.exe](RunningYourScript.html#using-nuix-console).

# Conditional Tests

## If

Ruby allows for conditional logic using the `if` statement.

```ruby
number = 10

if number == 10
	puts "The number equals 10"
end

if number != 10
	puts "The number is not equal to 10"
end

if number < 20
	puts "The number is less than 20"
end

if number <= 20
	puts "The number is less than or equal to 20"
end

if number > 5
	puts "The number is greater than 5"
end

if number >= 5
	puts "The number is greater than or equal to 5"
end
```

## Else

If you want to additionally have logic if a given test is `false` you may use `else`.

```ruby
number = 10

if number == 10
	puts "The number equals 10"
else
	puts "The number is not equal to 10"
end
```

## Else If

Ruby allows for multiple additional conditions using `elsif` (that is not a spelling error, it is spelled `elsif`).

```ruby
color = "red"

if color == "red"
	puts "The color is Red"
elsif color == "green"
	puts "The color is Green"
elsif color == "blue"
	puts "The color is Blue"
else
	puts "I do not recognize the color #{color}"
end
```

## Boolean Logic

### AND

If you want to test whether 2 or more conditions are `true` you may use the boolean AND operator `&&`.

```ruby
number = 42
color = "red"

#Test if number is greater than 10 AND color equals red
if number > 10 && color == "red"
	puts "Number is greater than 10 and the color is red"
else
	puts "Either number is not greater than 10 or color is not red"
end
```

### OR

If you want to test whether 1 of 2 or more conditions is `true` you may use the boolean OR operation `||`.

```ruby
number = 42
color = "red"

#Test if number is greater than 10 OR color equals red
if number > 10 || color == "red"
	puts "Number is greater than 10 and/or the color is red"
else
	puts "Number is less than or equal to 10 and color is not red"
end
```

### Complex Boolean Logic

Complex boolean logic can be formed using parenthesis.  This will control the order of operations such that entries within parentesis are evaluated first.

```ruby
number = 42
color = "red"
value = true

if (number == 42 && color == "red") || value == true
	puts "Number equals 42 and color is red"
	puts "Or"
	puts "Value equals true"
end
```

You can imagine the if condition to evalute like the following (left to right, parens first):

1. Initial expression  
`(number == 42 && color == "red") || value == true`
1. *number == 42* is **true**  
`(true && color == "red") || value == true`
1. *color == "red"* is **true**  
`(true && true) || value == true`
1. *true AND true* is **true*  
`(true) || value == true`
1. *value == true* is **true**  
`(true) || true`
1. *true OR true* is **true**  
`true`

### Logic Short Circuiting

Ruby uses [short circuit](https://en.wikipedia.org/wiki/Short-circuit_evaluation) evaluation.  The easiest way to understand this is with an example.

```ruby
some_value = nil
if some_value.empty? || some_value.nil?
	puts "Some value is nil or an empty string"
end
```

This script will cause the following error

```
NoMethodError: undefined method `empty?' for nil:NilClass
          (root) at <script>:2
```

The error is telling us that we are tring to call [empty?] on `some_value` which is [nil](#nil).  We can take advantage of the short circuit logic to prevent this though.

```ruby
some_value = nil
if some_value.nil? || some_value.empty?
	puts "Some value is nil or empty"
end
```

The difference in this example is that we instead first check for [nil](#nil) using the [nil?] method found on all types in Ruby.  If [nil?] returns `true`, this is enough to qualify the conditional statement as being `true` and the call to [empty?] is therefore never even tried.

This can be used to improve performance in some situations as well.  Imagine you are filtering a collection of items based on two criteria:

- Is an email
- Has duplicates

Testing whether an item is an email should be faster than getting the duplicates of an item.  We can use this to be more efficient.

```ruby
items = $current_case.search("meeting notes")
items.each do |item|
	if item.isKind("email") || item.getDuplicates.size > 0
		puts "It qualifies"
	end
end
```

Since this example tests whether an item is of kind email first, all items which are emails will not need to make the duplicate count check.  If you were to flip the conditions, all items would be checked for having duplicates and then checked for whether they are of the kind email.

## Case/When/Else

Rather than using multiple `elsif` statements in a row, it may be better to use a `case` statement (often called a `switch` statement in other languages).

```ruby
color = "red"

puts color

case color
when "red"
	puts "A warm color"
when "blue"
	puts "A cool color"
else
	puts "Unknown color"
end
```

A when statement may also handle multiple matches.

```ruby
color = "red"

puts color

case color
when "red", "orange"
	puts "A warm color"
when "blue", "green"
	puts "A cool color"
else
	puts "Unknown color"
end
```

# Methods

Ruby methods allow you to define a chunk of reusable code.

```ruby
def say_hello
	puts "Hello"
end

def say_bye
	puts "Bye"
end

say_hello
say_bye
```

```
Hello
Bye
```

**NHote**: Unlike some other languages, Ruby does not require `()` at the end of a method call.

Methods can also accept arguments, allowing them to be more flexible.

```ruby
def say_hello(name,age)
	puts "Hello #{name}, you are #{age} years old"
end

say_hello("Jason",34)
say_hello("Bob",42)
```

```
Hello Jason, you are 34 years old
Hello Bob, you are 42 years old
```

# Scripting Tricks

## Current Script File Path

Ruby defines `__FILE__` (two underscores on each side) which contains the file path of the current script, assuming your script is executing from a file and not the [Script Console](RunningYourScript.html#using-the-script-console).  This can be helpful if you script needs to refer to other files relative to the script itself.

```ruby
# Script file path is: C:\Scripts\testscript.rb
puts "Current Script File: #{__FILE__}"
puts "Current Script Directory: #{File.dirname(__FILE__)}"
```

**Example Output**

```
Current Script File: C:\Scripts\testscript.rb
Current Script Directory: C:\Scripts
```

## Current Method Name

You can get the name of the currently executing method using `__method__` (lower case with two underscores on each side).  This can be helpful sometimes when debugging an issue.

```ruby
puts "Current Method: #{__method__}"

def test_one
	puts "Current Method: #{__method__}"
end

def test_two
	puts "Current Method: #{__method__}"
end

test_one
test_two
```

**Example Output**

```
Current Method: 
Current Method: test_one
Current Method: test_two
```

## Java System Properties

JRuby provides `ENV_JAVA`, which is essentially a Ruby [Hash](#hash) containing the various Java system properties and their values.  This also includes arguments which may have been passed to Nuix.

For example, if I had started Nuix with the argument `-Dscript.casePath="C:\Cases\Case123"` I could retrieve this value using the following script:

```ruby
case_path = ENV_JAVA['script.casepath']
puts "Case Path Provided: #{case_path}"
```

**Example Output**

```
Case Path Provided: C:\Cases\Case123
```

[Array]: http://ruby-doc.org/core-1.9.3/Array.html
[Fixnum]: http://ruby-doc.org/core-1.9.3/Fixnum.html
[Bignum]: http://ruby-doc.org/core-1.9.3/Bignum.html
[Float]: http://ruby-doc.org/core-1.9.3/Float.html
[JavaString]: http://docs.oracle.com/javase/8/docs/api/java/lang/String.html
[Windows-1252]: http://en.wikipedia.org/wiki/Windows-1252
[nil]: #nil
[nil?]: http://ruby-doc.org/core-1.9.3/NilClass.html#method-i-nil-3F
[empty?]: http://ruby-doc.org/core-1.9.3/String.html#method-i-empty-3F