﻿- [What is Worker Side Scripting?](#what-is-working-side-scripting)
- [Information Available to a Worker Side Script](#information-available-to-a-worker-side-script)
  - [WorkerItem](#workeritem)
  - [SourceItem](#sourceitem)
- [Setup](#setup)
  - [Java Worker Side "Script"](#java-worker-side-script)
- [Basic Examples](#basic-examples)
  - [Basic Usage](#basic-usage)
  - [Add Tags](#add-tags)
  - [Tag by Term](#tag-by-term)
  - [Add Custom Metadata](#add-custom-metadata)
  - [Modify Item Properties](#modify-item-properties)
  - [Filter on Regular Expression](#filter-on-regular-expression)
  - [Filter on Communication Date](#filter-on-communication-date)
  - [Per Worker Logging](#per-worker-logging)
  - [Filter on Communication Date and Log Skipped Items](#filter-on-communication-date-and-log-skipped-items)


# What is Worker Side Scripting?

**Note**: If you have not already, I suggest you read the section on [[Loading Data]] before reading this section as the basic details of loading data into Nuix are not covered here.

Worker side scripting (*WSS* for short) allows you to provide Nuix with code which instructs Nuix workers how to handle items during ingestion.  The code is distributed to the workers when ingestion begins.  For each item that each worker processes, it runs your code at the worker, providing information about the item it is currently working on.  Your code may then inspect the item and inform the worker on how to proceed and even modify aspects of the item before being indexed/stored.

# Information Available to a Worker Side Script

When workers invoke your callback they provide a [WorkerItem] instance which contains information about the item the worker is about to process.  From the [WorkerItem] you are able to get addtional information from the associated [SourceItem] by calling [WorkerItem.getSourceItem].

## WorkerItem

Methods offered by [WorkerItem].

- **[addCustomMetadata][WorkerItem.addCustomMetadata]**: Can add custom metadata to each item
- **[addTag][WorkerItem.addTag]**: Can add tags to each item
- **[getGuidPath][WorkerItem.getGuidPath]**: Get the GUIDs of the items in the path
- **[getDigests][WorkerItem.getDigests]**: Gets the digests associated with the item by returning a [DigestCollection] item.
- Modify what processing occurs:
  - **[getProcessItem][WorkerItem.getProcessItem]** / **[setProcessItem][WorkerItem.setProcessItem]**: Whether to process the item at all 
  - **[getProcessEmbedded][WorkerItem.getProcessEmbedded]** / **[setProcessEmbedded][WorkerItem.setProcessEmbedded]**: Whether to process embedded items
  - **[getProcessImages][WorkerItem.getProcessImages]** / **[setProcessImages][WorkerItem.setProcessImages]**: Whether to process images for the item
  - **[getProcessText][WorkerItem.getProcessText]** / **[setProcessText][WorkerItem.setProcessText]**: Whether to process text of the item
  - **[getStoreBinary][WorkerItem.getStoreBinary]** / **[setStoreBinary][WorkerItem.setStoreBinary]**: Whether to store binary of the item
- **[getWorkerGuid][WorkerItem.getWorkerGuid]**: Get GUID of worker
- **[setItemText(string)][WorkerItem.setItemText(string)]**: Set the text using a string
- **[setItemText(file)][WorkerItem.setItemText(file)]**: Set the text using the text of a file
- **[getSourceItem][WorkerItem.getSourceItem]**: Get the [SourceItem] for the item being processed
- **[setItemProperties][WorkerItem.setItemProperties]**: Added in Nuix 7.0, this method allows you to provide a Hash/Map of properties to be used for a given item.  The properties indexed and stored for this item will be based on those present in the Hash/Map you provide.  If you wish to modify or extend the properties found by Nuix, first get those properties using [SourceItem.getProperties], make your changes to that Hash/Map, *then* call this method with your updated Hash/Map.

## SourceItem

Methods offered by [SourceItem].

- **[getBinary][SourceItem.getBinary]**: Get the associated [Binary] object for this item which provides information about the binary data of the object and access the bytes directly.
- **[getCommunication][SourceItem.getCommunication]**: Gets the associate [Communication] object, if there is one
- **[getImage][SourceItem.getImage]**: Get the associated [Image] object for this item which provides information about the image of this item.
- **[getText][SourceItem.getText]**: Get the associated [Text] object (not to be confused with the actual text) which provides information about the text of this item as well as access to the text.
- **[getKind][SourceItem.getKind]**: Get the [ItemKind] object for this item.
- **[getFileSize][SourceItem.getFileSize]**:  Get the file size of the item.
- **[getName][SourceItem.getName]**: Gets the item's name.  May return an empty string if the item has no name.
- **[getLocalisedName][SourceItem.getLocalisedName]**: Get the item's name.  If the item has no name will return a standard Nuix placeholder name such as `[Unnamed Image]`.
- **[getProperties][SourceItem.getProperties]**: Gets the properties associated with the item as a Java Map.  Modifications to this map are not reflected in the final item.
- **[getParent][SourceItem.getParent]**: Get the parent [SourceItem] of the given [SourceItem].
- **[getChildren][SourceItem.getChildren]**: Get the children [SourceItems][SourceItem] (immediate descendants) of the given [SourceItem], if there are any.
- **[getDescendants][SourceItem.getDescendants]**: Get the descendant [SourceItems][SourceItem] of the given [SourceItem], if there are any.
- **[getPath][SourceItem.getPath]**: Gets a list of [SourceItems][SourceItem] which represent the path from the root evidence container up to the given [SourceItem] itself.
- **[matchesSearch][SourceItem.matchesSearch]**: Checks if an item matches a search.

# Setup

There are two ways you are going to provide your worker side script to Nuix to be used while loading data.

The first way is to paste your worker side script code into the processing settings dialog in the GUI:

![Worker Side Script GUI](WorkerSideScriptingGUI.png)

The second way is via the API by passing the **code** of the script as a string setting while calling [Processor.setProcessingSettings].  This can be done inline in the same file like so using a Ruby [heredoc](http://ruby-doc.org/core-2.2.0/doc/syntax/literals_rdoc.html#label-Here+Documents):

```ruby
# Define the WSS ruby source as a multi line string inline to the main Ruby script
worker_side_script_code = <<CODE

# Define our worker item callback
def nuix_worker_item_callback(worker_item)
	# Do interesting things here
end

CODE

# Define our settings Hash
processing_settings = {
	# Other settings here...
	"workerItemCallback" => "ruby:"+worker_side_script_code,
	# Other settings here...
}

processor.setProcessingSettings(processing_settings)
```

**Note**: The script source code is prefixed with the scripting language of the code being provided, followed by a colon and then the worker side script code as a string.

Storing your worker side script inline as demonstrated in the previous example quickly becomes impractical as the worker side script gets more complex.  A better approach is to store the worker side script code in a separate file and load it:

```ruby
# Define path to a file containing worker side script code
path_to_wss = 'C:\NuixStuff\MyWorkerSideScriptCode.rb'

# Define our settings Hash
processing_settings = {
	# Other settings here...
	"workerItemCallback" => "ruby:"+File.read(path_to_wss),
	# Other settings here...
}

processor.setProcessingSettings(processing_settings)
```

## Java Worker Side "Script"

It is also possible to use a Java class as a worker side script.  The first step is to create a Java class which implements Consumer<WorkerItem> and AutoCloseable.

```java
package com.mycompany.worker;

public class WorkerItemConsumer implements Consumer<WorkerItem>, AutoCloseable {
	// Class constructor
	public WorkerItemConsumer() {
		// Initialization happens here
	}
	
	// This method is provided by the generic Consumer interface
	@Override
	public void accept(WorkerItem workerItem) {
		// Worker side logic here
	}
	
	// This method is provided by the AutoCloseable interface
	@Override
	public void close() throws Exception {
		// Cleanup/shutdown logic here
	}
}
```

Next you will need to compile this code into a Java JAR file and place the compiled file in the `lib` sub directory of your Nuix installation.  This step is important to ensure that when the worker processes are started they have access to the JAR.

From your script you specify the callback in a similar manner, but instead specify `java` as the language and the *fully qualified class name (including package)* where you previously specific the worker side script code.

```ruby
# Define our settings Hash
processing_settings = {
	# Other settings here...
	"workerItemCallback" => "java:com.mycompany.worker.WorkerItemConsumer",
	# Other settings here...
}

processor.setProcessingSettings(processing_settings)
```

# Basic Examples

## Basic Usage

In the least, the script you provide needs to define a method `nuix_worker_item_callback` in the root scope (not inside a class).

```ruby
# Define our worker item callback
def nuix_worker_item_callback(worker_item)
	# Do interesting things here
end
```

You may also provide a method `nuix_worker_item_callback_init` which will be called when the worker is initialized, allowing you to perform setup operations if needed.

```ruby
# Define our initialization callback
def nuix_worker_item_callback_init
	# Perform some setup here
end

# Define our worker item callback
def nuix_worker_item_callback(worker_item)
	# Do interesting things here
end
```

You may also define a method named `nuix_worker_item_callback_close` which will be called as the worker is shutting down.

```ruby
# Define our initialization callback
def nuix_worker_item_callback_init
	# Perform some setup here
end

# Define our worker item callback
def nuix_worker_item_callback(worker_item)
	# Do interesting things here
end

# Define our shutdown callback
def nuix_worker_item_callback_close
	# Do something on shutdown
end
```

## Add Tags

The following example applies the kind name as a tag to each item.

```ruby
# Define our worker item callback
def nuix_worker_item_callback(worker_item)
	# Get the associated SourceItem
	source_item = worker_item.getSourceItem
	
	# Use the source item to get the kind
	kind = source_item.getKind.getName
	
	# Tag the item with its kind name
	worker_item.addTag(kind)
end
```

## Tag by Term

This example will tag each item which contains one or more specified terms.

```ruby
# Define terms and tags
# Note that terms should be kept fairly simple as the query
# support from worker side scripting is simpler than elsewhere!
$term_data = {
	"cat" => "Animals|Cat",
	"bird" => "Animals|Bird",
	"coffee" => "Drinks|Coffee",
	"tea" => "Drinks|Tea",
	"pizza" => "Food|Pizza",
	"calzone" => "Food|Calzone"
}

# Define our worker item callback
def nuix_worker_item_callback(worker_item)
	# Get the associated SourceItem
	source_item = worker_item.getSourceItem
	
	# Use the source item to get the kind
	kind = source_item.getKind.getName
	
	# Test each term/query for a match, then tag it if it is a match
	$term_data.each do |term,tag|
		if source_item.matchesSearch(term)
			worker_item.addTag(tag)
		end
	end
end
```

## Add Custom Metadata

This example applies the item's type's kind name as custom metadata to each item.

```ruby
# Define our worker item callback
def nuix_worker_item_callback(worker_item)
	# Get the associated SourceItem
	source_item = worker_item.getSourceItem
	
	# Use the source item to get the kind
	kind = source_item.getKind.getName
	
	# Apply kind as custom metadata
	worker_item.add_custom_metadata("Item Kind", kind, "text", "user")
end
```

## Modify Item Properties

As of Nuix 7.0 [WorkerItem] has the method [setItemProperties][WorkerItem.setItemProperties] which allows you to change the property metadata indexed and stored for an item.

```ruby
# Define our worker item callback
def nuix_worker_item_callback(worker_item)
	# Get the associated SourceItem
	source_item = worker_item.getSourceItem
	
	# Use the source item to get the properties
	properties = source_item.getProperties
	
	# Delete a property
	properties.delete("CLSID")
	
	# Change a property if present
	if properties.has_key?("Author")
		properties["Author"] = properties["Author"] + " the cat" 
	end
	
	# Add a property (or overwrite if it already exists)
	properties["MagicNumber"] = Time.now.to_i
	
	# Finally store our updated properties Hash
	worker_item.setItemProperties(properties)
end
```

## Filter on Regular Expression

The following example uses regular expressions to scan the subject property of items which have it.  If the subject is found to have a match, a corresponding tag is then applied to the item.  The patterns are stored in a global variable `$patterns` so that the callback method has access to it.

```ruby
# Define some patterns we would like to match and the tags to apply
# when a match is made
$patterns = [
	{:regex => /^FWD:/i, :tag => "Email|Forward"},
	{:regex => /^RE:/i, :tag => "Email|Reply"},
]

# Define our worker item callback
def nuix_worker_item_callback(worker_item)
	# Get the associated SourceItem
	source_item = worker_item.getSourceItem

	# Get item properties
	properties = source_item.getProperties

	# Attempt to fetch the subject
	subject = properties["Subject"]

	# Check to make sure we actually have a subject
	if !subject.nil? && !subject.strip.empty?

		# Run each pattern against the subject
		$patterns.each do |pattern|

			# If regex matches, lets apply the tag
			if  subject =~ pattern[:regex]
				
				# Pattern matches, tag this item
				source_item.addTag(pattern[:tag])
			end
		end
	end
end
```

## Filter on Communication Date

This example will skip processing items which have a communication date with a year outside of a specified range.

```ruby
$min_year = 2001
$max_year = 2001

# Define our worker item callback
def nuix_worker_item_callback(worker_item)
	# Get the associated SourceItem
	source_item = worker_item.getSourceItem

	# Get the communication object
	communication = source_item.getCommunication
	
	# Check that we actually got a communication for this item
	if !communication.nil?
		# Get communication date
		date_time = communication.getDateTime
		# Get the year
		year = date_time.getYear
		# Are we outside our range?
		if year < $min_year || year > $max_year
			# We're outside our range, diable processing this item
			worker_item.setProcessItem(false)
		end
	end
end
```

## Per Worker Logging

Standard output from the workers does not show up at the Nuix instance you kick off the work from.  This example shows a way you may implement per worker logging to allow your script to report back information.  Each worker will write output to its own log text file named after the worker GUID.

```ruby
# Define a basic logging class
class Logger
	class << self
		attr_accessor :log_file
		def log(obj)
			message = "#{Time.now.strftime("%Y%m%d %H:%M:%S")}: #{obj}"
			File.open(@log_file,"a"){|f|f.puts message}
		end
	end
end

# Define our worker item callback
def nuix_worker_item_callback(worker_item)
	# Configure logger
	if Logger.log_file.nil?
		Logger.log_file = "C:\\temp\\WorkerScriptLog_#{worker_item.getWorkerGuid}.txt"
	end
	
	# Get the associated SourceItem
	source_item = worker_item.getSourceItem
	
	# Get the localised name
	name = source_item.getLocalisedName
	
	# Log the item's name.
	Logger.log("Callback invoked: #{name}")
end
```

## Filter on Communication Date and Log Skipped Items

This example combines the logging example and the communication date filtering example.  Items which are filtered out are logged.

```ruby
# Define a basic logging class
class Logger
	class << self
		attr_accessor :log_file
		def log(obj)
			message = "#{Time.now.strftime("%Y%m%d %H:%M:%S")}: #{obj}"
			File.open(@log_file,"a"){|f|f.puts message}
		end
	end
end

$min_year = 2001
$max_year = 2001

# Define our worker item callback
def nuix_worker_item_callback(worker_item)
	# Configure logger
	if Logger.log_file.nil?
		Logger.log_file = "C:\\temp\\WorkerScriptLog_#{worker_item.getWorkerGuid}.txt"
	end

	# Get the associated SourceItem
	source_item = worker_item.getSourceItem

	# Get the communication object
	communication = source_item.getCommunication
	
	# Check that we actually got a communication for this item
	if !communication.nil?
		# Get communication date
		date_time = communication.getDateTime
		# Get the year
		year = date_time.getYear
		# Are we outside our range?
		if year < $min_year || year > $max_year
			# We're outside our range, disable processing this item
			worker_item.setProcessItem(false)
			name = source_item.getLocalisedName
			Logger.log("Skipped item: #{name}, #{date_time}")
		end
	end
end
```


[WorkerItem]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/WorkerItem.html
[WorkerItem.addCustomMetadata]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/WorkerItem.html#addCustomMetadata-java.lang.String-java.lang.Object-java.lang.String-java.lang.String-
[WorkerItem.addTag]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/WorkerItem.html#addTag-java.lang.String-
[WorkerItem.getGuidPath]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/WorkerItem.html#getGuidPath--
[WorkerItem.getProcessItem]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/WorkerItem.html#getProcessItem--
[WorkerItem.setProcessItem]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/WorkerItem.html#setProcessItem-boolean-
[WorkerItem.getProcessEmbedded]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/WorkerItem.html#getProcessEmbedded--
[WorkerItem.setProcessEmbedded]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/WorkerItem.html#setProcessEmbedded-boolean-
[WorkerItem.getProcessImages]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/WorkerItem.html#getProcessImages--
[WorkerItem.setProcessImages]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/WorkerItem.html#setProcessImages-boolean-
[WorkerItem.getProcessText]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/WorkerItem.html#getProcessText--
[WorkerItem.setProcessText]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/WorkerItem.html#setProcessText-boolean-
[WorkerItem.getStoreBinary]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/WorkerItem.html#getStoreBinary--
[WorkerItem.setStoreBinary]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/WorkerItem.html#setStoreBinary-boolean-
[WorkerItem.getSourceItem]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/WorkerItem.html#getSourceItem--
[WorkerItem.getWorkerGuid]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/WorkerItem.html#getWorkerGuid--
[WorkerItem.setItemText(string)]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/WorkerItem.html#setItemText-java.lang.String-
[WorkerItem.setItemText(file)]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/WorkerItem.html#setItemText-java.io.File-
[WorkerItem.setItemProperties]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/WorkerItem.html#setItemProperties-java.util.Map-

[SourceItem]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/SourceItem.html
[SourceItem.getCommunication]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/SourceItem.html#getCommunication--
[SourceItem.getBinary]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/SourceItem.html#getBinary--
[SourceItem.getImage]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/SourceItem.html#getImage--
[SourceItem.getCommunication]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/SourceItem.html#getCommunication--
[SourceItem.getText]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/SourceItem.html#getText--
[SourceItem.getFileSize]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemMetadata.html#getFileSize--
[SourceItem.getKind]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemMetadata.html#getKind--
[SourceItem.getName]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemMetadata.html#getName--
[SourceItem.getLocalisedName]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemMetadata.html#getLocalisedName--
[SourceItem.getProperties]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemMetadata.html#getProperties--
[SourceItem.getType]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemMetadata.html#getType--
[SourceItem.getChildren]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemTreeNode.html#getChildren--
[SourceItem.getDescendants]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemTreeNode.html#getDescendants--
[SourceItem.getParent]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemTreeNode.html#getParent--
[ItemKind]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemKind.html
[SourceItem.getPath]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemTreeNode.html#getPath--
[SourceItem.matchesSearch]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/SearchableItem.html#matchesSearch-java.lang.String-


[Communication]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Communication.html
[Binary]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Binary.html
[Image]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Image.html
[Text]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Text.html
[WorkerItem.getDigests]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/WorkerItem.html#getDigests--
[DigestCollection]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/DigestCollection.html
[Processor.setProcessingSettings]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/Processor.html#setProcessingSettings-java.util.Map-