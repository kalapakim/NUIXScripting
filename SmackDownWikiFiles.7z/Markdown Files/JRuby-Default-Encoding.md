# JRuby Default Encoding

Nuix is written in Java.  Java stores [String][JavaString] data internally as UTF-16.  This is great because it relieves many of the concerns a developer might have about whether Unicode string data will get truncated while being stored.

JRuby is a Ruby interpreter written in Java that allows Java code to run Ruby scripts which can then make calls into Java.  Nuix uses JRuby to provide Ruby scripting capabilities.

When JRuby passes a string object from Java to a Ruby script it is running, JRuby converts the encoding of the String before handing it to the Ruby code, based upon the Java system property `file.encoding`.  You can see what this encoding is currently set to by running the following line of Ruby code.

```ruby
puts ENV_JAVA['file.encoding']
```

On most Windows machines, this value will be

```
Cp1252
```

Cp1252 (also known as [Windows-1252], which may be incorrectly referred to as ANSI) cannot fit some of the higher order Unicode characters.

So what does this mean for Strings when they are passed from Java through JRuby into your Ruby code?  Unicode characters which do not "fit" into this encoding become '?', something most of us have seen happen before.

How do you handle this situation?  Well ideally you would be able to change this property at run-time from your script and continue coding happily.  Unfortunately its more complex than that.  It turns out that some internal mechanism of Java caches this property as the JVM is starting, such that changing this value later has no effect in this situation.

The solution is to set this value as the JVM is starting up using an argument to the JVM similar to the following:

```
-Dfile.encoding=utf8
```

If you were to start Nuix with this argument then this line of code:

```ruby
puts ENV_JAVA['file.encoding']
```

Should instead output

```
utf8
```

Want to enforce this in a script?  Its easy to do:
```ruby
if ENV_JAVA['file.encoding'].downcase == "cp1252"
    #Notify user
    puts "Your default encoding is: #{ENV_JAVA['file.encoding']}"    
    puts "Please restart with argument\n-Dfile.encoding=utf8"
    #Exit the script to enforce this
    puts "Script exiting..."
    exit 1
end
    
#Work you scripting magic here
```

Which would output something like to this if the default encoding is `Cp1252`:

```
Your default encoding is: Cp1252
Please restart with argument
-Dfile.encoding=utf8
Script exiting...
```
