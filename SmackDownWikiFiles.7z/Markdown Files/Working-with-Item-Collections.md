- [General](#general)
  - [Iterating](#iterating)
  - [Select](#select)
  - [Reject](#reject)
  - [Map](#map)
- [Item Utility](#item-utility)
  - [Deduplication](#deduplication)
  - [Resolving Items to Top Level](#resolving-items-to-top-level)
  - [Resolving the Descendants of Items](#resolving-the-descendants-of-items)
  - [Resolving the Family Members of Items](#resolving-the-family-members-of-items)
  - [Resolving the Deduplicates of Items](#resolving-the-duplicates-of-items)
  - [Set Operations](#set-operations)
    - [Difference](#difference)
    - [Intersection](#intersection)
    - [Union](#union)
- [Item Sorter](#item-sorter)
  - [Sort by Position](#sort-by-position)
  - [Sort by Top Level Item Date](#sort-by-top-level-item-date)
  - [Sort Using Custom Expression](#sort-using-custom-expression)

Nuix makes [[searching]] for items a very simple task.  Once you have the results of a search you may just provide those results to another API method for operations like [[Tagging|Annotations]] or [[Exporting]], but often times you will need to manipulate the resulting collection of items in some way.

This could be something as simple as [iterating](#iterating) each item to report some information or [selecting](#select) which items you want to use in the next step.  This may also be more complex operations such as [resolving family members](#resolving-the-family-members-of-items) of each item.

This section of the guide is discusses ways you can work with these collections of items.

# General

## Iterating

Iterating each individual item in a collection of items using `each`.

```ruby
# Search for some items
items = $current_case.search("flag:audited")
# Iterate each item
items.each do |item|
	puts item.getName
end
```

## Select
The following example uses `select` to create a new collection of items which contains the items for which the provided block evaluates to `true`.

```ruby
items = $current_case.search("")
audited_items = items.select{|item| item.isAudited}
```

The long hand equivalent might look like this.

```ruby
items = $current_case.search("")
audited_items = items.select do |item|
	next item.isAudited
end
```

Using `select` is essentially a convenience to using `each` in the following manner:

```ruby
items = $current_case.search("")
audited_items = []
items.each do |item|
	if item.isAudited == true
		# If isAudited is true for this item then append
		# this item to audited_items array
		audited_items << item
	end
end
```

## Reject

Using `reject` is similar to using `select` except you get the items for which your provided block returns `false`.

```ruby
items = $current_case.search("")
non_audited_items = items.reject{|item| item.isAudited}
```

The long hand equivalent might look like this.

```ruby
items = $current_case.search("")
non_audited_items = items.reject do |item|
	next item.isAudited
end
```

Using `reject` is essentially a convenience method to using `each` in the following manner:

```ruby
items = $current_case.search("")
non_audited_items = []
items.each do |item|
	if item.isAudited == false
		# If isAudited is false for this item then append
		# this item to audited_items array
		audited_items << item
	end
end
```

## Map

Mapping is the process of creating a new collection from an existing collection by *mapping* the source to something new.  The following example creates a collection of item GUIDs from a collection of items.

```ruby
items = $current_case.search("")
guids = items.map{|item| item.getGuid}
```

The long hand equivalent of this might look like the following:

```ruby
items = $current_case.search("")
guids = items.map do |item|
	item.getGuid
end
```

Using `map` is essentially a convenience method to using `each` in the following manner:

```ruby
items = $current_case.search("")
guids = []
items.each do |item|
	guids << item.getGuid
end
```

# Item Utility

Nuix provides the [ItemUtility] object to perform some additional Nuix specific item collection manipulation beyond those provided by Ruby such as:

* [Deduplication](#deduplication)
* [Resolving Items to Top Level](#resolving-items-to-top-level)
* [Resolving the Descendants of Items](#resolving-the-descendants-of-items)
* [Resolving the Family Members of Items](#resolving-the-family-members-of-items)

Additionally [ItemUtility] provides some methods for [Set Theory](https://en.wikipedia.org/wiki/Set_theory) style manipulations (think [Venn Diagrams](https://en.wikipedia.org/wiki/Venn_diagram)):

* [Difference](#difference)
* [Intersection](#intersection)
* [Union](#union)

**Note:** All the methods of ItemUtility return a Java [Set](https://docs.oracle.com/javase/8/docs/api/java/util/Set.html) of items.  This is discussed in more detail in the section [Reading the API Documentation](ReadingTheAPIDocumentation.html#translating-java-types-to-ruby).

## Deduplication

Nuix provides various ways to deduplicate a collection of items.  The simplest is using the basic form of [ItemUtility.deduplicate]:

```ruby
items = $current_case.search("")
iutil = $utilities.getItemUtility
deduplicated_items = iutil.deduplicate(items)
```

The Nuix API also includes a way to customize this deduplication process by providing a custom expression which yields the "hash" value to be used for comparison while deduplicating using an alternate version of the [ItemUtility.deduplicate](https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemUtility.html#deduplicate-java.util.Collection-nuix.ItemExpression-) method which accepts an expression as an additional argument.

```ruby
items = $current_case.search("")
iutil = $utilities.getItemUtility
# Deduplicate using item name instead of MD5
deduplicated_by_name_items = iutil.deduplicate(items) do |item|
	next item.getName
end
```

## Resolving Items to Top Level

The [ItemUtility] object provides the method [ItemUtility.findTopLevelItems] to resolve a collection of items to a [Set] of their top level items.

```ruby
items = $current_case.search("")
iutil = $utilities.getItemUtility
top_level_items = iutil.findTopLevelItems(items)
```

## Resolving the Descendants of Items

The [ItemUtility] object provides the method [ItemUtility.findDescendants] to resolve a [Collection] of items to a [Set] of their descendants:

```ruby
items = $current_case.search("")
iutil = $utilities.getItemUtility
descendants = iutil.findDescendants(items)
```

If you wish to resolve the descendants and include the input [Collection] of items, you can instead use [ItemUtility.findItemsAndDescendants]:

```ruby
items = $current_case.search("")
iutil = $utilities.getItemUtility
items_and_descendants = iutil.findItemsAndDescendants(items)
```

## Resolving the Family Members of Items

The [ItemUtility] object provides the method [ItemUtility.findFamilies] to resolve a [Collection] of items to a [Set] of items and their family members:

```ruby
items = $current_case.search("")
iutil = $utilities.getItemUtility
families = iutil.findFamilies(items)
```

This operation is similar to if you were to resolve a [Collection] of input items to their top level items, and then include their descendants.

## Resolving the Duplicates of Items

The [ItemUtility] object provides the method [ItemUtility.findItemsAndDuplicates] to resolve a [Collection] of items to a [Set] of items and their duplicates.

```ruby
items = $current_case.search("")
iutil = $utilities.getItemUtility
items_and_duplicates = iutil.findItemsAndDuplicates(items)
```

## Set Operations

### Difference

![Difference](difference.png)

The [ItemUtility] object provides the method [ItemUtility.difference] which allows you to "subtract" from the items in one [Collection], the items of a second [Collection].

```ruby
items_a = $current_case.search(query_a)
items_b = $current_case.search(query_b)
iutil = $utilities.getItemUtility
difference_items = iutil.difference(items_a, items_b)
```

### Intersection

![Intersection](intersection.png)

The [ItemUtility] object provides the method [ItemUtility.intersection] which allows you calculate the intersection [Set] of items in two item [Collections][Collection] (only items which are present in both collections).

```ruby
items_a = $current_case.search(query_a)
items_b = $current_case.search(query_b)
iutil = $utilities.getItemUtility
in_both_items = iutil.intersection(items_a, items_b)
```

### Union

![Union](union.png)

The [ItemUtility] object provides the method [ItemUtility.union] which allows you calculate the union [Set] of items in two item [Collections][Collection] (all items from both collections).  Since the result is a [Set], no item should occur more than once within the result.

```ruby
items_a = $current_case.search(query_a)
items_b = $current_case.search(query_b)
iutil = $utilities.getItemUtility
all_items = iutil.union(items_a, items_b)
```

# Item Sorter

The Nuix API includes an object called the [ItemSorter].  This assists in sorting a [List] of items by:

* Position (the order encountered during processing)
* Top level item date (ascending or descending)
* Custom value via an expression

## Sort by Position

Sorting a [List] of items is performed using the [ItemSorter.sortItemsByPosition] method.

```ruby
items = $current_case.search("flag:audited")
sorter = $utilities.getItemSorter
sorted_items = sorter.sortItemsByPosition(items)
```

## Sort by Top Level Item Date

Sorting a [List] of items by their top level item date in ascending order is performed using the [ItemSorter.sortItemsByTopLevelItemDate] method.

```ruby
items = $current_case.search("flag:audited")
sorter = $utilities.getItemSorter
sorted_items = sorter.sortItemsByTopLevelItemDate(items)
```

And in descending order using [ItemSorter.sortItemsByTopLevelItemDateDescending].

```ruby
items = $current_case.search("flag:audited")
sorter = $utilities.getItemSorter
sorted_items = sorter.sortItemsByTopLevelItemDateDescending(items)
```

## Sort Using Custom Expression

The [ItemSorter] object also allows for sorting via a custom expression where you provide a value per item which is then used for sort comparison.

```ruby
items = $current_case.search("flag:audited")
sorter = $utilities.getItemSorter
# Sort items by audited size
sorted_items = sorter.sortItems(items) do |item|
	next item.getAuditedSize
end
```

Items which yield the same value are secondarily sorted by the input order.  The following script demonstrates this.

```ruby
items = $current_case.search("").take(10)

puts "== Search Result Order =="
original_sort_value = {}
items.each_with_index do |item,index|
	puts "#{index} | #{item.getPosition}"
	original_sort_value[item] = index
end

sorter = $utilities.getItemSorter

puts "\n== Random Value Sorted =="
assigned_sort_value = {}
sorted_items_b = sorter.sortItems(items) do |item|
	rando = rand(0..5)
	assigned_sort_value[item] = rando
	next rando
end
puts "Sort Value | Original | Tree Position"
sorted_items_b.each do |item|
	original = original_sort_value[item]
	assigned = assigned_sort_value[item]
	puts "#{assigned.to_s.rjust(10)} | #{original.to_s.rjust(8)} | #{item.getPosition}"
end
```

Example Output

```
== Search Result Order ==
0 | [1]
1 | [0]
2 | [2]
3 | [1, 0]
4 | [2, 0]
5 | [0, 0]
6 | [0, 0, 0]
7 | [0, 0, 2]
8 | [0, 0, 3]
9 | [0, 0, 1]

== Random Value Sorted ==
Sort Value | Original | Tree Position
         0 |        8 | [0, 0, 3]
         1 |        2 | [2]
         1 |        5 | [0, 0]
         3 |        3 | [1, 0]
         3 |        7 | [0, 0, 2]
         3 |        9 | [0, 0, 1]
         4 |        1 | [0]
         4 |        4 | [2, 0]
         5 |        0 | [1]
         5 |        6 | [0, 0, 0]
```

As the output demonstrates, multiple items with the same "sort value" (the value yielded by the custom expression) are subsequently in the "original" order.


[ItemUtility]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemUtility.html
[ItemUtility.deduplicate]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemUtility.html#deduplicate-java.util.Collection-
[ItemUtility.findTopLevelItems]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemUtility.html#findTopLevelItems-java.util.Collection-
[ItemUtility.findDescendants]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemUtility.html#findDescendants-java.util.Collection-
[ItemUtility.findItemsAndDescendants]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemUtility.html#findItemsAndDescendants-java.util.Collection-
[ItemUtility.findItemsAndDuplicates]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemUtility.html#findItemsAndDuplicates-java.util.Collection-
[ItemUtility.findFamilies]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemUtility.html#findFamilies-java.util.Collection-
[ItemUtility.intersection]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemUtility.html#intersection-java.util.Collection-java.util.Collection-
[ItemUtility.union]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemUtility.html#union-java.util.Collection-java.util.Collection-
[ItemUtility.difference]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemUtility.html#difference-java.util.Collection-java.util.Collection-
[Collection]: https://docs.oracle.com/javase/8/docs/api/java/util/Collection.html
[Set]: https://docs.oracle.com/javase/8/docs/api/java/util/Set.html
[List]: https://docs.oracle.com/javase/8/docs/api/java/util/List.html
[ItemSorter]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemSorter.html
[ItemSorter.sortItemsByTopLevelItemDate]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemSorter.html#sortItemsByTopLevelItemDate-java.util.List-
[ItemSorter.sortItemsByTopLevelItemDateDescending]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemSorter.html#sortItemsByTopLevelItemDateDescending-java.util.List-
[ItemSorter.sortItemsByPosition]: https://download.nuix.com/releases/desktop/stable/docs/en/scripting/api/nuix/ItemSorter.html#sortItemsByPosition-java.util.List-