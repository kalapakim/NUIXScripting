# Menu Title: Annotate Physical Item Path
# Needs Case: true
# Needs Selected Items: false

script_directory = File.dirname(__FILE__)
require File.join(script_directory,"Nx.jar")
java_import "com.nuix.nx.NuixConnection"
java_import "com.nuix.nx.LookAndFeelHelper"
java_import "com.nuix.nx.dialogs.ChoiceDialog"
java_import "com.nuix.nx.dialogs.CustomDialog"
java_import "com.nuix.nx.dialogs.TabbedCustomDialog"
java_import "com.nuix.nx.dialogs.CommonDialogs"
java_import "com.nuix.nx.dialogs.ProgressDialog"

LookAndFeelHelper.setWindowsIfMetal
NuixConnection.setUtilities($utilities)
NuixConnection.setCurrentNuixVersion(NUIX_VERSION)

dialog = TabbedCustomDialog.new("Annotate Physical Item Path")

main_tab = dialog.addTab("main_tab","Main")
main_tab.appendTextField("custom_field_name","Custom Field Name","PhysicalItemPath")
main_tab.appendCheckBox("remove_evidence_container","Remove Evidence Container from Path",false)

dialog.validateBeforeClosing do |values|
	if values["custom_field_name"].strip.empty?
		CommonDialogs.showWarning("Custom Field Name cannot be blank.")
		next false
	end

	# Get user confirmation about closing all workbench tabs
	if CommonDialogs.getConfirmation("The script needs to close all workbench tabs, proceed?") == false
		next false
	end

	next true
end

dialog.display
if dialog.getDialogResult == true
	$window.closeAllTabs
	values = dialog.toMap
	custom_field_name = values["custom_field_name"]
	remove_evidence_container = values["remove_evidence_container"]
	iutil = $utilities.getItemUtility
	annotater = $utilities.getBulkAnnotater

	ProgressDialog.forBlock do |pd|
		pd.setTitle("Annotate Physical Item Path")
		pd.setMainStatusAndLogIt("Locating physical file items...")
		physical_items = $current_case.searchUnsorted("flag:physical_file")
		pd.logMessage("Physical Items: #{physical_items.size}")

		pd.setMainProgress(0,physical_items.size)
		physical_items.each_with_index do |physical_item,physical_item_index|
			header = "(#{physical_item_index+1}/#{physical_items.size}) #{physical_item.getLocalisedName}"
			pd.setMainStatus(header)
			pd.logMessage("\n==== #{header} ====")
			pd.setMainProgress(physical_item_index+1)

			pd.setSubStatusAndLogIt("Calculating physical item path...")
			physical_item_path = []
			physical_item.getPath.each do |path_item|
				next if (remove_evidence_container && path_item.getType.getName == "application/vnd.nuix-evidence")
				physical_item_path << path_item
				if path_item.isPhysicalFile
					break
				end
			end
			physical_item_path = physical_item_path.map{|i|i.getLocalisedName}.join("/")
			pd.logMessage("Physical Item Path: #{physical_item_path}")

			pd.setSubStatusAndLogIt("Locating descendants....")
			physical_descendants = iutil.findItemsAndDescendants([physical_item])
			pd.logMessage("Physical Item and Descendants Count: #{physical_descendants.size}")

			pd.setSubStatusAndLogIt("Annotating items with physical item path...")
			pd.setSubProgress(0,physical_descendants.size)
			annotater.putCustomMetadata(custom_field_name,physical_item_path,physical_descendants) do |info|
				pd.setSubProgress(info.getStageCount)
			end
		end

		$window.openTab("workbench",{:search => ""})
		pd.setCompleted
	end
end